# 高校辅导员备考 Skill v1.0 可用题库交付版

## Incremental Word-first real-exam import (2026-07-14)

The v1.2 update imports 1,880 deduplicated questions from 82 `.docx` files, using paired PDFs only as provenance evidence. The usable total changes from 10,681 to 12,561. 66 exact duplicates were suppressed, 10 source files remain review-only, and 13 training-material files were excluded. When a Word source did not provide an answer or explanation, the field remains blank; nothing was inferred.

## Incremental real-exam intake (2026-07-14)

This release registers 81 newly supplied PDFs without treating the containing folder as proof of provenance. 49 individual-exam candidates, 18 provincial compilations, and 2 unknown candidates remain in review; 12 training-material PDFs are excluded. Because the environment did not provide a reliable PDF/OCR extraction chain, no unverified questions were added to `question-bank/usable`; the usable total remains 10681. See `reports/incremental-2026-07-14/` before using these sources.

## 这是什么

这是面向中国高校辅导员招聘考试备考者的通用备考辅助 Skill，可用于政策复习、笔试刷题、案例分析、结构化面试、公文写作、时政复习、答案批改和错题复盘。

## 适合谁

适合正在准备高校辅导员招聘考试、需要系统训练笔试和面试表达的普通备考者。

## 不适合谁

不适合把它当作官方真题库、最新招聘公告库、政策原文库或考试通过保证工具的人。

## 它能做什么

- 制定 30 天或 14 天备考计划
- 从可用题库中出题训练
- 批改简答题、论述题、案例分析和面试回答
- 讲解辅导员岗位、学生工作和思政教育相关考点
- 组织每日训练和错题复盘
- 辅助公文写作训练
- 复习 2025-2026 时政材料

## 它不能保证什么

不能保证题库全部来自官方原题，不能替代目标高校公告和官方政策文件，不能保证考试通过。

## 如何开始

打开 `quick-start.md`，复制其中任一指令给 ChatGPT。

## 每日训练

建议每天完成：政策复习 20 分钟、客观题 20-30 道、主观题 1-2 道、案例或面试 1 道、错题复盘 10 分钟。

## 笔试训练

可按题型、考点或综合套题训练。客观题适合自测，主观题适合作答后批改。

## 案例分析训练

先独立作答，再让 Skill 按案例分析评分规则批改，重点看定性、原因、措施和后续跟进。

## 结构化面试训练

可要求 Skill 扮演考官，进行追问和点评。重点训练表达结构、岗位认知和应急处理能力。

## 答案批改

粘贴你的答案，让 Skill 按题型评分，并给出修改版。没有标准答案的开放题，会按评分规则批改。

## 政策复习

政策解释优先参考 `references/counselor-core-policy-cards.md`，不要把培训资料当作官方依据。

## 时政复习

时政复习优先参考 `references/current-affairs-2025-2026.md` 和可用题库中的时政题。旧时政不得当作最新时政。

## 题库说明

默认题库为 `question-bank/usable/`，总题量 10681 道：

- 选择题：891
- 判断题：21
- 填空题：364
- 简答题：645
- 论述题：89
- 案例分析题：112
- 结构化面试题：124
- 时政专项题：5621
- 公文写作题：243
- 混合题型：2571
- 需要人工核对但仍可使用：9640

判断题数量较少，不建议把高数量判断题训练作为默认训练目标。时政题数量较多，使用时要注意时效性。

## 题库风险

题库来源包括培训资料、模拟题、真题回忆、OCR/Word 转换资料。部分题目没有标准答案或解析，部分题目需要人工核对。参加具体考试前，应以目标高校公告和官方文件为准。

## 当前版本限制

v1.0 是可用题库交付版，不包含 full-extraction 工程备份、raw-materials、converted-text 或旧分层题库。

## 使用建议

把它当作训练系统，而不是答案权威。先作答，再批改；先理解政策，再套用表达；先练结构，再追求亮点。

## 免责声明

本 Skill 仅用于备考训练，不能替代官方政策、招聘公告或个人判断，不能保证考试通过。

## 统一题库风险提示

- 默认题库为 `question-bank/usable`。
- usable-question-bank 总题量为 10681 道。
- 需要人工核对但仍可使用的题目为 9640 道。
- 判断题数量较少，为 21 道；不要默认承诺高数量判断题训练。
- 时政专项题较多，为 5621 道；时政内容具有时效性。
- 混合题型较多，为 2571 道；适合综合训练和进一步拆分复盘。
- 本题库不是官方真题库。
- 培训资料不能当作官方依据。
- 真题回忆不能当作严格真题。
- 旧时政不得当作最新时政。
- 本 Skill 不能替代最新招聘公告。
- 本 Skill 不能保证考试通过。

## v1.3.0 联合增量修复

本版本将 13 个误列为 excluded 的备考资料恢复到独立分类库：训练题库 2181 条、公文/博文写作参考 35 条、历史政策专题 144 条，均不进入 `real_exam` 检索。江苏省高校真题回忆中有 32 条题干完整、来源可追溯的记录进入 `real_exam`，保留 `memory_version=true` 且不补答案；`3.2 【江苏省】29校真题.docx` 因 Word 无文本运行继续 review。联合审计报告位于 `reports/combined-training-and-jiangsu-recovery-2026-07-14/`。

检索时必须区分真实招聘真题、真题回忆、训练材料、写作参考和历史政策资料；真题回忆不得表述为官方严格真题，历史资料不得当作现行政策权威。

