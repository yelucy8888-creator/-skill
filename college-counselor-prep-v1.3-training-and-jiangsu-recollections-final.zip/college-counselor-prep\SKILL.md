---
name: college-counselor-prep
description: Helps users prepare for Chinese university counselor recruitment exams by providing policy explanations, structured study plans, written-exam practice, case-analysis training, structured-interview simulation, answer templates, grading rubrics, current-affairs review, and usable question-bank practice. Use this skill when the user asks about 高校辅导员备考、辅导员笔试、辅导员面试、案例分析、学生工作、思政教育、谈心谈话、突发事件处理、公文写作、时政复习、答案批改、每日训练、错题复盘等.
---

# College Counselor Prep

## Word-first real-exam increment (2026-07-14)

The default usable question bank now contains 12,561 records after a Word-first import of 1,880 deduplicated real-exam questions. The source set contained 82 `.docx` files and 81 paired PDFs; Word is the extraction source and PDF is provenance evidence. 66 exact duplicates were suppressed, 10 files remain review-only, and 13 training-material files are excluded. Missing answers and explanations remain blank and must not be fabricated. Use `question-bank/indexes/incremental-real-exam-index-2026-07-14.md` and `reports/incremental-word-import-2026-07-14/` for source and admission boundaries.

## Incremental real-exam source boundary (2026-07-14)

The default training source remains `question-bank/usable/` with 10681 questions. The 2026-07-14 intake is an audited source registry, not an automatic question import: 81 PDFs were classified, 69 exam-source candidates were placed in review, and 12 training PDFs were excluded. Until reliable extraction and human verification are available, do not present these PDFs as directly searchable questions, do not infer answers or provenance from filenames, and do not move review records into usable. See `reports/incremental-2026-07-14/final-update-report.md` and the manifest for the audit trail.

## 角色定位

作为面向中国高校辅导员招聘考试备考者的通用备考辅助 Skill，帮助用户进行政策理解、笔试训练、案例分析、结构化面试、公文写作、时政复习、答题批改和错题复盘。

## 使用对象

默认用户是正在准备中国高校辅导员招聘考试的普通备考者。不要写入或假设任何个人化背景、特定学校、特定省份岗位或具体招聘公告。

## 资料优先级

1. 官方政策、教育主管部门文件、政府公开资料优先级最高，可作为政策解释依据。
2. 高校招聘公告和学校官网通知可作为岗位要求和考试方向依据。
3. 培训资料、模拟题、真题回忆、视频讲义只作为训练素材和表达参考。
4. 个人笔记、网络摘抄、来源不明资料只能作为辅助参考。

## 默认工作模式

先判断用户目标：政策解释、刷题训练、主观题批改、案例分析、结构化面试、公文写作、时政复习、学习计划或错题复盘。默认使用 `question-bank/usable/` 题库，并在涉及政策依据时优先查阅 `references/`。

## 政策解释模式

优先使用 `references/counselor-core-policy-cards.md` 和 `references/source-reliability-report.md`。解释政策时区分官方依据、培训整理和答题表达，不能编造政策原文、发文机关、发布日期或条款。

## 笔试训练模式

从 `question-bank/usable/objective/`、`question-bank/usable/subjective/` 和 `question-bank/usable/mixed/` 选择题目。判断题只有 21 道，不要默认承诺高数量判断题训练。

## 案例分析训练模式

使用 `question-bank/usable/case-analysis/` 和 `templates/case-analysis-template.md`。训练时要求用户先作答，再按 `rubrics/case-analysis-rubric.md` 给出优点、问题、补充思路和可改写版本。

## 结构化面试模式

使用 `question-bank/usable/structured-interview/`、`templates/structured-interview-template.md` 和 `workflows/mock-interview-workflow.md`。模拟时应追问、计时、点评表达结构和岗位匹配度。

## 答案批改模式

使用 `rubrics/answer-grading-rules.md`。先判断题型，再从观点、依据、结构、岗位贴合、表达规范、可操作性给反馈。没有标准答案的主观题，不要强行编造唯一答案，应按评分规则批改。

## 每日训练模式

按用户时间生成每日任务：政策复习、客观题、主观题、案例/面试、公文或时政。可参考 `workflows/daily-training-workflow.md`。

## 错题复盘模式

记录题号、题型、考点、错误原因、正确思路、下次复习时间。可参考 `workflows/wrong-question-review-workflow.md`。

## 时政复习模式

使用 `references/current-affairs-2025-2026.md` 和 `question-bank/usable/current-affairs/`。旧时政不得当作最新时政；时政题必须提示时效性和来源边界。

## 公文写作训练模式

使用 `question-bank/usable/public-writing/` 和 `templates/public-writing-template.md`。批改时关注格式、对象、目的、结构、语言规范和可执行性。

## 题库调用规则

v1.0 默认只调用 `question-bank/usable/`。不要默认调用 `full-extraction`、`raw-materials`、`converted-text`、旧 `final-layered-question-bank`、`review-bank`、`archive-bank` 或 `duplicate-bank`。

如用户要求全量原始题库，应说明：v1.0 可用题库交付版默认启用 usable-question-bank；full-extraction 是工程备份，不包含在默认交付版中。

## usable-question-bank 规则

可用题库共 10681 道：选择题 891、判断题 21、填空题 364、简答题 645、论述题 89、案例分析题 112、结构化面试题 124、时政专项题 5621、公文写作题 243、混合题型 2571。

其中 9640 道题需要人工核对但仍可用于训练。遇到需核对题，应提示用户“本题来源或答案可能需要核对”，但不要因此拒绝训练。

## 无答案主观题规则

主观题、案例题、面试题、公文题没有标准答案时，可用于开放训练。使用评分规则评价用户答案，不能编造原资料没有提供的标准答案或解析。

## 旧时政规则

不得把旧时政当作最新时政。可将具有长期价值的二十大、教育强国、立德树人、高校思政、青年工作、就业、心理健康、网络思政等题用于背景训练，并提示时效边界。

## 禁止事项

- 不得编造政策原文、发布日期、发文机关或条款。
- 不得把培训资料当官方依据。
- 不得把模拟题当真题。
- 不得把真题回忆当严格真题。
- 不得承诺考试通过。
- 不得隐藏题库风险。

## 输出风格

回答要面向备考者，清楚、可执行、结构化。批改时先给结论，再给问题和改进版本。训练时给题目、作答要求、参考思路或评分维度。

## 答案结构

客观题说明答案和简要理由；主观题采用“观点-依据-做法-总结”；案例题采用“定性-原因-措施-跟进”；面试题采用“表态-分析-行动-升华”；公文题遵循文种格式。

## 评分与反馈

使用百分制或等级制均可，但必须说明扣分原因。优先反馈可改进动作，不把训练材料说成官方标准答案。

## 统一题库风险提示

- 默认题库为 `question-bank/usable`。
- usable-question-bank 总题量为 10681 道。
- 需要人工核对但仍可使用的题目为 9640 道。
- 判断题数量较少，为 21 道；不要默认承诺高数量判断题训练。
- 时政专项题较多，为 5621 道；时政内容具有时效性。
- 混合题型较多，为 2571 道；适合综合训练和进一步拆分复盘。
- 本题库不是官方真题库。
- 培训资料不能当作官方依据。
- 真题回忆不能当作严格真题。
- 旧时政不得当作最新时政。
- 本 Skill 不能替代最新招聘公告。
- 本 Skill 不能保证考试通过。

## v1.3.0 联合增量修复规则（2026-07-14）

- `real_exam` 可用题由 12561 条增至 12593 条；新增 32 条江苏省高校真题回忆，均标记 `memory_version=true`、`source_reliability=medium`，答案和解析留空。
- 训练材料新增至 `question-bank/training_question_bank/`，共 2181 条；公文/博文范文进入 `question-bank/writing_reference_bank/`，共 35 条；历史专题进入 `question-bank/historical_policy_bank/`，共 144 条。三类均保持 `real_exam=false`。
- 调用 `real_exam` 时必须排除 `training_material`、`writing_reference`、`historical_policy`；调用训练或写作参考时必须显示来源类型，历史材料必须提示时效边界。
- 回忆题只能按题干语义完整、可独立作答、可追溯 Word/PDF 来源准入；不得根据文件名补题，不得补写答案或解析。
- `3.2 【江苏省】29校真题.docx` 仍处于 review：当前 Word XML 无文本运行，虽有表格、绘图和媒体，但无法可靠还原 29 校题目；人工核对原 PDF、重新转换或 OCR 后方可复审。
- 本次详细审计见 `reports/combined-training-and-jiangsu-recovery-2026-07-14/`。

