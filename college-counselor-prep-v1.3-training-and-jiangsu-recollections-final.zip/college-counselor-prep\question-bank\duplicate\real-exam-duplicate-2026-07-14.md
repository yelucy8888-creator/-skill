# Real-exam duplicate layer — 2026-07-14

66 candidate questions were identified as exact duplicates against existing usable records or within the batch. They were not added again to usable. Full mappings are in `reports/incremental-word-import-2026-07-14/exact-duplicate-report.md`.
