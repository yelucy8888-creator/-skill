# historical usable — 2026-07-14

source_type is not real_exam.

## HIST-20260714-0001

### item_id

HIST-20260714-0001

### original_question

新矛盾

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0002

### item_id

HIST-20260714-0002

### original_question

一带一路

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0003

### item_id

HIST-20260714-0003

### original_question

两个必须认识到

### question_type

term_definition

### options



### answer

(十九大报告中针对新矛盾提出) 必须认识到，我国社会主要矛盾的变化是关系全局的历史性变化，对党和国家工作提出了许多新要求 必须认识到，我国社会主要矛盾的变化，没有改变我们对我国社会主义所处历史阶段的判断。我国仍处于并将长期处于社会主义初级阶段的基本国情没有变，我国是世界最大发展中国家的国际地位没有变

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0004

### item_id

HIST-20260714-0004

### original_question

两个阶段

### question_type

term_definition

### options



### answer

(十九大报告中针对建设社会主义现代化强国提出) 第一个阶段，从二○二○年到二○三五年，在全面建成小康社会的基础上，再奋斗十五年，基本实现社会主义现代化 第二个阶段，从二○三五年到本世纪中叶，在基本实现现代化的基础上，再奋斗十五年，把我国建成富强民主文明和谐美丽的社会主义现代化强国

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0005

### item_id

HIST-20260714-0005

### original_question

两学一做

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0006

### item_id

HIST-20260714-0006

### original_question

两个巩固

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0007

### item_id

HIST-20260714-0007

### original_question

“两大历史性课题”

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0008

### item_id

HIST-20260714-0008

### original_question

三大作风

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0009

### item_id

HIST-20260714-0009

### original_question

三个统一

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0010

### item_id

HIST-20260714-0010

### original_question

三严三实

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0011

### item_id

HIST-20260714-0011

### original_question

三会 一课

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0012

### item_id

HIST-20260714-0012

### original_question

“三型”政党

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0013

### item_id

HIST-20260714-0013

### original_question

三大国家战略

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0014

### item_id

HIST-20260714-0014

### original_question

“遵循三个规律”

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0015

### item_id

HIST-20260714-0015

### original_question

四个伟大

### question_type

term_definition

### options



### answer

(十九大报告中提出) 伟大斗争，伟大工程，伟大事业，伟大梦想，紧密联系、相互贯通、相互作用，其中起决定性作用的是党的建设新的伟大工程

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0016

### item_id

HIST-20260714-0016

### original_question

四个意识

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0017

### item_id

HIST-20260714-0017

### original_question

四大考验

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0018

### item_id

HIST-20260714-0018

### original_question

四种危险

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0019

### item_id

HIST-20260714-0019

### original_question

四讲四有

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0020

### item_id

HIST-20260714-0020

### original_question

四进四信

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0021

### item_id

HIST-20260714-0021

### original_question

四个服从

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0022

### item_id

HIST-20260714-0022

### original_question

四项基本原则

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0023

### item_id

HIST-20260714-0023

### original_question

四有教师

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0024

### item_id

HIST-20260714-0024

### original_question

“四个自我” 能力

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0025

### item_id

HIST-20260714-0025

### original_question

监督执纪“四种形态”

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0026

### item_id

HIST-20260714-0026

### original_question

四个全面

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0027

### item_id

HIST-20260714-0027

### original_question

“四个坚持不懈”

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0028

### item_id

HIST-20260714-0028

### original_question

“四个服务”

### question_type

term_definition

### options



### answer

(社会主义大学的办学方向) 为人民服务，为中国共产党治国理政服务，为巩固和发展中国特色社会主义制度服务， 为改革开放和社会主义现代化建设服务

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0029

### item_id

HIST-20260714-0029

### original_question

“四个铁一般”

### question_type

term_definition

### options



### answer

(“四铁”干部队伍) 铁一般信仰、铁一般信念、铁一般纪律、铁一般担当

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0030

### item_id

HIST-20260714-0030

### original_question

四条底线

### question_type

term_definition

### options



### answer

(党员干部做人做事) 法律底线、纪律底线、政策底线、道德底线

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0031

### item_id

HIST-20260714-0031

### original_question

四点希望

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0032

### item_id

HIST-20260714-0032

### original_question

“四个统一”

### question_type

term_definition

### options



### answer

(加强高校师资队伍建设) 坚持教书和育人相统一： 坚持言传和身教相统一 坚持潜心问道和关注社会相统一： 坚持学术自由和学术规范相统一

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0033

### item_id

HIST-20260714-0033

### original_question

“四个正确认识”

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0034

### item_id

HIST-20260714-0034

### original_question

“五个必须”

### question_type

term_definition

### options



### answer

(在十八届中央纪委第五次全会上，习近平总书记提出：如何做到自觉遵守规矩?答案是，要做到“五个必须”。) 一是必须维护党中央权威 二是必须维护党的团结 三是必须遵循组织程序 四是必须服从组织决定 五是必须管好亲属和身边工作人员

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0035

### item_id

HIST-20260714-0035

### original_question

五大发展理念

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0036

### item_id

HIST-20260714-0036

### original_question

党组织建设五方面

### question_type

term_definition

### options



### answer

(十九大党章修订后) 政治建设、思想建设、组织建设、作风建设、纪律建设

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0037

### item_id

HIST-20260714-0037

### original_question

党的建设必须坚决实现以下五项基本要求

### question_type

term_definition

### options



### answer

(十九大党章修订后) 坚持党的基本路线；坚持解放思想，实事求是，与时俱进，求真务实；坚持全心全意为人民服务；坚持民主集中制；坚持从严管党治党

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0038

### item_id

HIST-20260714-0038

### original_question

好干部五条标准 (20字标准)

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0039

### item_id

HIST-20260714-0039

### original_question

总书记对青年的五点要求

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0040

### item_id

HIST-20260714-0040

### original_question

“六个坚持”

### question_type

term_definition

### options



### answer

(党对做好群团工作的基本要求) 坚持党对群团工作的统一领导， 坚持发挥桥梁和纽带作用， 坚持围绕中心、服务大局， 坚持服务群众的工作生命线，坚持与时俱进、改革创新， 坚持依法依章程独立自主开展工作

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0041

### item_id

HIST-20260714-0041

### original_question

高等学校教师职业道德规范

### question_type

term_definition

### options



### answer

(六条) 一、爱国守法。二、敬业爱生。三、教书育人 四、严谨治学。五、服务社会。六、为人师表

### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0042

### item_id

HIST-20260714-0042

### original_question

“七个有之”

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0043

### item_id

HIST-20260714-0043

### original_question

八项规定

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0044

### item_id

HIST-20260714-0044

### original_question

中国精神

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0045

### item_id

HIST-20260714-0045

### original_question

高校的立身之本

### question_type

term_definition

### options



### answer



### explanation



### source_file

2-04【名词解释】核心50题.docx

### source_pdf_file

2-04【名词解释】核心50题.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

not_provided

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0046

### item_id

HIST-20260714-0046

### original_question

中国共产党第十九次全国代表大会，是在全面建成小康社会决胜阶段、中国特色社会主义进入 的关键时期召开的一次十分重要的大会

### question_type

choice

### options

A.新时期 B.新阶段 C.新征程D.新时代

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0047

### item_id

HIST-20260714-0047

### original_question

十九大的主题是：不忘初心， ，高举中国特色社会主义伟大旗帜，决胜全面建成小康社会，夺取新时代中国特色社会主义伟大胜利，为实现中华民族伟大复兴的中国梦不懈奋斗

### question_type

choice

### options

A.继续前进 B.牢记使命 C.方得始终 D.砥砺前行

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0048

### item_id

HIST-20260714-0048

### original_question

中国共产党人的初心和使命，就是为中国人民 ，为中华民族 。这个初心和使命是激励中国共产党人不断前进的根本动力

### question_type

choice

### options

A.谋幸福，谋未来 B.谋生活，谋复兴；C.谋幸福，谋复兴 D.谋生活，谋未来

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0049

### item_id

HIST-20260714-0049

### original_question

五年来，我们统筹推进“ ”总体布局、协调推进“ ”战略布局，“十二五”规划胜利完成，“十三五”规划顺利实施，党和国家事业全面开创新局面

### question_type

choice

### options

A.五位一体四个全面 B.四位一体五个全面；C.五个全面四位一体 D.四个全面五位一体

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0050

### item_id

HIST-20260714-0050

### original_question

过去五年，经济保持中高速增长，在世界主要国家中名列前茅，国内生产总值从五十四万亿元增长到 万亿元，稳居世界第二，对世界经济增长贡献率超过百分之三十

### question_type

choice

### options

A.六十 B.七十 C.八十 D.九十

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0051

### item_id

HIST-20260714-0051

### original_question

脱贫攻坚战取得决定性进展， 贫困人口稳定脱贫，贫困发生率从百分之十点二下降到百分之四以下

### question_type

choice

### options

A.六千多万 B.七千多万 C.八千多万 D.九千多万

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0052

### item_id

HIST-20260714-0052

### original_question

实施共建“一带一路”倡议，发起创办亚洲基础设施投资银行，设立丝路基金，举办首届“一带一路”国际合作高峰论坛、亚太经合组织领导人非正式会议、二十国集团领导人 峰会、金砖国家领导人 会晤、亚信峰会

### question_type

choice

### options

A.北京南京 B.杭州厦门 C.南京北京 D.厦门杭州

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0053

### item_id

HIST-20260714-0053

### original_question

坚持反腐败无禁区、全覆盖、零容忍，坚定不移“打虎”、“拍蝇”、“猎狐”， 的目标初步实现， 的笼子越扎越牢， 的堤坝正在构筑，反腐败斗争压倒性态势已经形成并巩固发展

### question_type

choice

### options

A.不敢腐不能腐不想腐 B.不能腐不敢腐不想腐；C.不想腐不敢腐不能腐 D.不敢腐不想腐不能腐

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0054

### item_id

HIST-20260714-0054

### original_question

经过长期努力，中国特色社会主义进入了新时代，这是我国发展新的

### question_type

choice

### options

A.未来方向 B.未来方位C.历史方向 D.历史方位

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0055

### item_id

HIST-20260714-0055

### original_question

中国特色社会主义进入新时代，我国社会主要矛盾已经转化为人民日益增长的 需要和 的发展之间的矛盾

### question_type

choice

### options

A.美好生活不充分不平衡 B.幸福生活不平衡不充分；C.幸福生活不充分不平衡 D.美好生活不平衡不充分

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0056

### item_id

HIST-20260714-0056

### original_question

必须认识到，我国社会主要矛盾的变化，没有改变我们对我国社会主义所处历史阶段的判断，我国仍处于并将长期处于 的基本国情没有变，我国是世界最大发展中国家的国际地位没有变

### question_type

choice

### options

A.社会主义阶段 B.社会主义初级阶段；C.社会主义中级阶段 D.社会主义高级阶段

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0057

### item_id

HIST-20260714-0057

### original_question

是实现社会主义现代化、创造人民美好生活的必由之路

### question_type

choice

### options

A.中国特色社会主义道路 B.中国特色社会主义理论体系；C.中国特色社会主义制度 D.中国特色社会主义文化

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0058

### item_id

HIST-20260714-0058

### original_question

是指导党和人民实现中华民族伟大复兴的正确理论

### question_type

choice

### options

A.中国特色社会主义道路 B.中国特色社会主义理论体系；C.中国特色社会主义制度 D.中国特色社会主义文化

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0059

### item_id

HIST-20260714-0059

### original_question

是当代中国发展进步的根本制度保障

### question_type

choice

### options

A.中国特色社会主义道路 B.中国特色社会主义理论体系；C.中国特色社会主义制度 D.中国特色社会主义文化

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0060

### item_id

HIST-20260714-0060

### original_question

中国特色社会主义文化是激励全党全国各族人民奋勇前进的强大精神力量

### question_type

choice

### options

A.中国特色社会主义道路 B.中国特色社会主义理论体系；C.中国特色社会主义制度 D.中国特色社会主义文化

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0061

### item_id

HIST-20260714-0061

### original_question

新时代中国特色社会主义思想，明确坚持和发展中国特色社会主义，总任务是实现社会主义现代化和中华民族伟大复兴，在全面建成小康社会的基础上，分 在本世纪中叶建成富强民主文明和谐美丽的社会主义现代化强国

### question_type

choice

### options

A.两步走 B.三步走C.四步走 D.五步走

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0062

### item_id

HIST-20260714-0062

### original_question

新时代中国特色社会主义思想，明确中国特色社会主义最本质的特征是

### question_type

choice

### options

A.“五位一体”总体布局 B.建设中国特色社会主义法治体系；C.人民利益为根本出发点 D.中国共产党领导

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0063

### item_id

HIST-20260714-0063

### original_question

发展是解决我国一切问题的基础和关键，发展必须是科学发展，必须坚定不移贯彻 的发展理念

### question_type

choice

### options

A.创新、协调、绿色、开放、共享 B.创造、协调、生态、开放、共享；C.创新、统筹、绿色、开放、共享 D.创造、统筹、生态、开放、共享

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0064

### item_id

HIST-20260714-0064

### original_question

是中国特色社会主义的本质要求和重要保障

### question_type

choice

### options

A.全面依法治国 B.全面从严治党 C.全面发展经济 D.全面可持续发展

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0065

### item_id

HIST-20260714-0065

### original_question

是一个国家、一个民族发展中更基本、更深沉、更持久的力量

### question_type

choice

### options

A.道路自信 B.理论自信 C.制度自信 D.文化自信

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0066

### item_id

HIST-20260714-0066

### original_question

必须统筹国内国际两个大局，始终不渝走和平发展道路、奉行 的开放战略

### question_type

choice

### options

A.互利共赢 B.互相合作 C.包容互信 D.开放共赢

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0067

### item_id

HIST-20260714-0067

### original_question

从现在到二○二○年，是全面建成小康社会

### question_type

choice

### options

A.决战期 B.决胜期 C.关键期 D.攻坚期

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0068

### item_id

HIST-20260714-0068

### original_question

从 到 ，是“两个一百年”奋斗目标的历史交汇期

### question_type

choice

### options

A.二○二○年二○三五年；B.十九大二十大；C.二十大二十一大；D.二○三五年本世纪中叶

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0069

### item_id

HIST-20260714-0069

### original_question

综合分析国际国内形势和我国发展条件，从二○二○年到本世纪中叶可以分两个阶段来安排。第一个阶段，从 到 ，在全面建成小康社会的基础上，再奋斗十五年，基本实现社会主义现代化

### question_type

choice

### options

A.二○二○年二○三五年 B.二○二五年二○四○年；C.二○三○年二○四五年 D.二○三五年本世纪中叶

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0070

### item_id

HIST-20260714-0070

### original_question

综合分析国际国内形势和我国发展条件，从二○二○年到本世纪中叶可以分两个阶段来安排。第二个阶段，从 到 ，在基本实现现代化的基础上，再奋斗十五年，把我国建成富强民主文明和谐美丽的社会主义现代化强国

### question_type

choice

### options

A.二○二○年二○三五年 B.二○三五年二○五○年；C.二○三○年二○四五年 D.二○三五年本世纪中叶

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0071

### item_id

HIST-20260714-0071

### original_question

从全面建成小康社会到基本实现现代化，再到全面建成 ，是新时代中国特色社会主义发展的战略安排

### question_type

choice

### options

A.创新型国家 B.社会主义现代化强国；C.社会主义现代化大国 D.世界一流强国

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0072

### item_id

HIST-20260714-0072

### original_question

我国经济已由 阶段转向 阶段，正处在转变发展方式、优化经济结构、转换增长动力的攻关期，建设现代化经济体系是跨越关口的迫切要求和我国发展的战略目标

### question_type

choice

### options

A.高速增长高水平发展 B.高速发展高水平发展；C.高速增长高质量发展 D.高速发展高质量发展

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0073

### item_id

HIST-20260714-0073

### original_question

贯彻新发展理念，建设现代化经济体系，必须坚持质量第一、效益优先，以 为主线

### question_type

choice

### options

A.转变发展方式 B.优化经济结构；C.供给侧结构性改革 D.转换增长动力

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0074

### item_id

HIST-20260714-0074

### original_question

建设现代化经济体系，必须把发展经济的着力点放在 上，把提高供给体系质量作为主攻方向，显著增强我国经济质量优势

### question_type

choice

### options

A.实体经济 B.共享经济 C.虚拟经济 D.国民经济

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0075

### item_id

HIST-20260714-0075

### original_question

是引领发展的第一动力，是建设现代化经济体系的战略支撑

### question_type

choice

### options

A.改革 B.创新 C.开放 D.科技

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0076

### item_id

HIST-20260714-0076

### original_question

保持土地承包关系稳定并长久不变，第二轮土地承包到期后再延长 年

### question_type

choice

### options

A.二十 B.三十 C.四十 D.五十

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0077

### item_id

HIST-20260714-0077

### original_question

确保到 我国现行标准下农村贫困人口实现脱贫，贫困县全部摘帽，解决区域性整体贫困，做到脱真贫、真脱贫

### question_type

choice

### options

A.二○三○年 B.二○二○年 C.二○二五年 D.二○三五年

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0078

### item_id

HIST-20260714-0078

### original_question

加快完善社会主义市场经济体制。经济体制改革必须以 和 为重点，实现产权有效激励、要素自由流动、价格反应灵活、竞争公平有序、企业优胜劣汰

### question_type

choice

### options

A.完善产权制度要素市场化配置 B.要素市场化配置建立现代财政制度；C.建立现代财政制度创新和完善宏观调控；D.完善产权制度创新和完善宏观调控

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0079

### item_id

HIST-20260714-0079

### original_question

推动形成全面开放新格局。要以 建设为重点，坚持引进来和走出去并重，遵循共商共建共享原则，加强创新能力开放合作，形成陆海内外联动、东西双向互济的开放格局

### question_type

choice

### options

A.“金砖机制”B.自贸区C.“一带一路”D.区域合作

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0080

### item_id

HIST-20260714-0080

### original_question

赋予自由贸易试验区更大改革自主权，探索建设

### question_type

choice

### options

A.自由贸易城B.自由贸易区 C.自由贸易港 D.自由贸易市

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0081

### item_id

HIST-20260714-0081

### original_question

坚持党的领导、人民当家作主、依法治国有机统一。 是社会主义民主政治的本质特征

### question_type

choice

### options

A.党的领导 B.人民当家作主C.依法治国 D.政治体制改革

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0082

### item_id

HIST-20260714-0082

### original_question

加强人民当家作主制度保障。 是坚持党的领导、人民当家作主、依法治国有机统一的根本政治制度安排

### question_type

choice

### options

A.人民代表大会制度 B.多党合作和政治协商制度；C.民族区域自治制度 D.基层群众自治制度

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0083

### item_id

HIST-20260714-0083

### original_question

发挥社会主义协商民主重要作用。 是具有中国特色的制度安排，是社会主义协商民主的重要渠道和专门协商机构

### question_type

choice

### options

A.政党协商 B.人大协商C.基层协商 D.人民政协

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0084

### item_id

HIST-20260714-0084

### original_question

深化依法治国实践。成立中央全面 领导小组，加强对法治中国建设的统一领导

### question_type

choice

### options

A.深化改革B.依法治国C.从严治党 D.司法改革

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0085

### item_id

HIST-20260714-0085

### original_question

深化机构和行政体制改革。转变政府职能，深化简政放权，创新监管方式，增强政府公信力和执行力，建设人民满意的 政府

### question_type

choice

### options

A.法治B.创新型 C.廉洁 D.服务型

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0086

### item_id

HIST-20260714-0086

### original_question

全党必须牢记， 的问题，是检验一个政党、一个政权性质的试金石

### question_type

choice

### options

A.为什么人 B.执政宗旨C.建党宗旨 D.权力来源

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0087

### item_id

HIST-20260714-0087

### original_question

建设 是中华民族伟大复兴的基础工程

### question_type

choice

### options

A.经济强国 B.政治强国C.教育强国 D.文化强国

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0088

### item_id

HIST-20260714-0088

### original_question

国家安全是安邦定国的重要基石， 是全国各族人民根本利益所在

### question_type

choice

### options

A.加快经济发展 B.维护国家统一C.促进国际合作 D.维护国家安全

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0089

### item_id

HIST-20260714-0089

### original_question

我们要建设的现代化是人与自然 的现代化

### question_type

choice

### options

A.和谐相处 B.和睦相处C.和谐共生 D.和睦共生

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0090

### item_id

HIST-20260714-0090

### original_question

加快建立绿色生产和消费的法律制度和政策导向，建立健全 的经济体系

### question_type

choice

### options

A.绿色低碳循环发展 B.绿色节约循环发展；C.绿色低碳节约发展 D.节约低碳循环发展

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0091

### item_id

HIST-20260714-0091

### original_question

加强对生态文明建设的总体设计和组织领导，设立 机构

### question_type

choice

### options

A.国有自然资源资产管理和自然环境监管；B.国有自然资源资产管理和自然生态监管；C.国有自然资源资产监管和自然生态管理；D.国有自然环境资产监管和自然生态管理

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0092

### item_id

HIST-20260714-0092

### original_question

我们要牢固树立社会主义生态文明观，推动形成 现代化建设新格局，为保护生态环境作出我们这代人的努力！

### question_type

choice

### options

A.人与自然和谐共生 B.人与环境和谐发展；C.人与自然和谐发展 D.人与环境和谐共生

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0093

### item_id

HIST-20260714-0093

### original_question

适应世界新军事革命发展趋势和国家安全需求，提高建设质量和效益，确保到二○二○年基本实现 ， 建设取得重大进展， 有大的提升

### question_type

choice

### options

A.现代化信息化战斗能力 B.机械化信息化战斗能力；C.机械化信息化战略能力 D.现代化信息化战略能力

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0094

### item_id

HIST-20260714-0094

### original_question

力争到二○三五年 国防和军队现代化，到本世纪中叶把人民军队 世界一流军队

### question_type

choice

### options

A.全面实现基本建成 B.全面实现全面建成；C.基本实现基本建成 D.基本实现全面建成

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0095

### item_id

HIST-20260714-0095

### original_question

树立 是核心战斗力的思想，推进重大技术创新、自主创新，加强军事人才培养体系建设，建设创新型人民军队

### question_type

choice

### options

A.创新 B.科技C.人才 D.技术

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0096

### item_id

HIST-20260714-0096

### original_question

军队是要准备打仗的，一切工作都必须坚持 标准，向能打仗、打胜仗聚焦

### question_type

choice

### options

A.战斗力 B.斗争力C.战争力 D.硬实力

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0097

### item_id

HIST-20260714-0097

### original_question

解决台湾问题、实现祖国完全统一，是全体中华儿女 ，是中华民族 所在

### question_type

choice

### options

A.一致愿望根本利益 B.共同愿望本质利益；C.一致愿望本质利益 D.共同愿望根本利益

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0098

### item_id

HIST-20260714-0098

### original_question

是两岸关系的政治基础

### question_type

choice

### options

A.“九二共识”B.反对“台独” C.一个中国原则 D.和平统一

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0099

### item_id

HIST-20260714-0099

### original_question

我们呼吁，各国人民同心协力，构建人类命运共同体，建设 的世界

### question_type

choice

### options

A.持久和平、普遍安全、共同繁荣、开放包容、公平正义；B.持久和平、普遍安全、共同繁荣、公平正义、清洁美丽；C.持久和平、普遍安全、共同繁荣、开放包容、清洁美丽；D.持久和平、普遍安全、公平正义、开放包容、清洁美丽

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0100

### item_id

HIST-20260714-0100

### original_question

深刻认识党面临的 的尖锐性和严峻性，坚持问题导向，保持战略定力，推动全面从严治党向纵深发展

### question_type

choice

### options

A.精神懈怠危险、能力不足危险、脱离群众危险、消极腐败危险；B.精神懈怠危险、封闭僵化危险、脱离群众危险、消极腐败危险；C.精神懈怠危险、能力不足危险、官僚主义危险、消极腐败危险；D.精神懈怠危险、能力不足危险、脱离群众危险、腐化堕落危险

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0101

### item_id

HIST-20260714-0101

### original_question

党的 是党的根本性建设，决定党的建设方向和效果

### question_type

choice

### options

A.思想建设 B.政治建设C.组织建设 D.制度建设

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0102

### item_id

HIST-20260714-0102

### original_question

要尊崇党章，严格执行新形势下党内政治生活若干准则，增强党内政治生活的

### question_type

choice

### options

A.政治性、时代性、原则性、战斗性；B.思想性、政治性、时代性、原则性；C.政治性、思想性、时代性、原则性；D.政治性、思想性、时代性、战斗性

### answer

A

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0103

### item_id

HIST-20260714-0103

### original_question

坚决防止和反对 ，坚决防止和反对宗派主义、圈子文化、码头文化，坚决反对搞两面派、做两面人

### question_type

choice

### options

A.个人主义、享乐主义、自由主义、本位主义、好人主义；B.个人主义、分散主义、山头主义、本位主义、好人主义；C.个人主义、分散主义、自由主义、本位主义、好人主义；D.个人主义、分散主义、自由主义、本位主义、享乐主义

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0104

### item_id

HIST-20260714-0104

### original_question

和 ，是中国共产党人的精神支柱和政治灵魂，也是保持党的团结统一的思想基础

### question_type

choice

### options

A.共产主义远大理想新时代中国特色社会主义共同理想；B.共产主义远大理想中国特色社会主义共同理想；C.共产主义崇高理想新时代中国特色社会主义共同理想；D.共产主义崇高理想中国特色社会主义共同理想

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0105

### item_id

HIST-20260714-0105

### original_question

要坚持党管干部原则， ，把好干部标准落到实处

### question_type

choice

### options

A.坚持立场坚定、素质过硬，坚持五湖四海、任人唯贤，坚持事业为上、公道正派；B.坚持德才兼备、以德为先，坚持立场坚定、素质过硬，坚持事业为上、公道正派；C.坚持德才兼备、以德为先，坚持五湖四海、任人唯贤，坚持立场坚定、素质过硬；D.坚持德才兼备、以德为先，坚持五湖四海、任人唯贤，坚持事业为上、公道正派

### answer

D

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0106

### item_id

HIST-20260714-0106

### original_question

要以提升 为重点，突出政治功能，把企业、农村、机关、学校、科研院所、街道社区、社会组织等基层党组织建设成为宣传党的主张、贯彻党的决定、领导基层治理、团结动员群众、推动改革发展的坚强战斗堡垒

### question_type

choice

### options

A.凝聚力 B.领导力 C.组织力 D.战斗力

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0107

### item_id

HIST-20260714-0107

### original_question

要坚持无禁区、全覆盖、零容忍，坚持 ，坚持受贿行贿一起查，坚决防止党内形成利益集团

### question_type

choice

### options

A.重预防、强高压、长震慑 B.重遏制、强高压、长震慑；C.重遏制、不减压、长震慑 D.重遏制、强高压、长威慑

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0108

### item_id

HIST-20260714-0108

### original_question

增强党自我净化能力，根本靠强化 和

### question_type

choice

### options

A.党的自我监督舆论监督 B.党的自我监督群众监督；C.党的自我监督司法监督 D.党的自我监督民主监督

### answer

B

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0109

### item_id

HIST-20260714-0109

### original_question

推进 ，建设覆盖纪检监察系统的检举举报平台。强化不敢腐的震慑，扎牢不能腐的笼子，增强不想腐的自觉，通过不懈努力换来海晏河清、朗朗乾坤

### question_type

choice

### options

A.监察领域国家立法 B.预防腐败国家立法；C.反腐败国家立法 D.廉政国家立法

### answer

C

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0110

### item_id

HIST-20260714-0110

### original_question

全党同志一定要永远与人民 、 、 ，永远把人民对美好生活的向往作为奋斗目标，以永不懈怠的精神状态和一往无前的奋斗姿态，继续朝着实现中华民族伟大复兴的宏伟目标奋勇前进

### question_type

choice

### options

A.同呼吸B.共命运 C.手牵手 D.心连心

### answer

ABD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0111

### item_id

HIST-20260714-0111

### original_question

过去五年，开放型经济新体制逐步健全， 、 、 稳居世界前列

### question_type

choice

### options

A.对外贸易 B.对外投资 C.外汇储备 D.外汇支出

### answer

ABC

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0112

### item_id

HIST-20260714-0112

### original_question

科学立法、严格执法、公正司法、全民守法深入推进， 、 、 建设相互促进，中国特色社会主义法治体系日益完善，全社会法治观念明显增强

### question_type

choice

### options

A.法治生活 B.法治国家 C.法治政府 D.法治社会

### answer

BCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0113

### item_id

HIST-20260714-0113

### original_question

引导应对气候变化国际合作，成为全球生态文明建设的重要

### question_type

choice

### options

A.参与者 B.贡献者C.引领者 D.领导者

### answer

ABC

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0114

### item_id

HIST-20260714-0114

### original_question

出台中央八项规定，严厉整治 、 、 和 ，坚决反对特权

### question_type

choice

### options

A.形式主义B.官僚主义 C.享乐主义；D.奢靡之风E.个人主义

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0115

### item_id

HIST-20260714-0115

### original_question

五年来，我们勇于面对党面临的重大风险考验和党内存在的突出问题，以顽强意志品质正风肃纪、反腐惩恶，消除了党和国家内部存在的严重隐患，党内政治生活气象更新，党内政治生态明显好转，党的 显著增强

### question_type

choice

### options

A.创造力B.创新力C.凝聚力 D.战斗力

### answer

ACD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0116

### item_id

HIST-20260714-0116

### original_question

坚持 的要求，开展党的群众路线教育实践活动和“三严三实”专题教育，推进“两学一做”学习教育常态化制度化，全党理想信念更加坚定、党性更加坚强

### question_type

choice

### options

A.照镜子 B.正衣冠 C.洗洗澡 D.治治病

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0117

### item_id

HIST-20260714-0117

### original_question

这个新时代，是

### question_type

choice

### options

A.承前启后、继往开来、在新的历史条件下继续夺取中国特色社会主义伟大胜利的时代；B.决胜全面建成小康社会、进而全面建设社会主义现代化强国的时代；C.全国各族人民团结奋斗、不断创造美好生活、逐步实现全体人民共同富裕的时代；D.全体中华儿女勠力同心、奋力实现中华民族伟大复兴中国梦的时代；E.我国日益走近世界舞台中央、不断为人类作出更大贡献的时代

### answer

ABCDE

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0118

### item_id

HIST-20260714-0118

### original_question

全党要更加自觉地增强 、 、 、 ，既不走封闭僵化的老路，也不走改旗易帜的邪路，保持政治定力，坚持实干兴邦，始终坚持和发展中国特色社会主义

### question_type

choice

### options

A.道路自信B.理论自信C.制度自信D.文化自信E.思想自信

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0119

### item_id

HIST-20260714-0119

### original_question

新时代中国特色社会主义思想，是 ，必须长期坚持并不断发展

### question_type

choice

### options

A.对马克思列宁主义、毛泽东思想、邓小平理论、“三个代表”重要思想、科学发展观的继承和发展；B.马克思主义中国化最新成果；C.党和人民实践经验和集体智慧的结晶；D.中国特色社会主义理论体系的重要组成部分；E.全党全国人民为实现中华民族伟大复兴而奋斗的行动指南

### answer

ABCDE

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0120

### item_id

HIST-20260714-0120

### original_question

新时代坚持和发展中国特色社会主义的基本方略是

### question_type

choice

### options

A.坚持党对一切工作的领导，坚持以人民为中心，坚持全面深化改革；B.坚持新发展理念，坚持人民当家作主，坚持全面依法治国；C.坚持社会主义核心价值体系，坚持在发展中保障和改善民生，坚持人与自然和谐共生；D.坚持总体国家安全观，坚持党对人民军队的绝对领导，坚持“一国两制”和推进祖国统一；E.坚持推动构建人类命运共同体，坚持全面从严治党

### answer

ABCDE

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0121

### item_id

HIST-20260714-0121

### original_question

党政军民学，东西南北中，党是领导一切的。必须增强 ，自觉维护党中央权威和集中统一领导，自觉在思想上政治上行动上同党中央保持高度一致

### question_type

choice

### options

A.政治意识 B.大局意识C.核心意识 D.看齐意识E.纪律意识

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0122

### item_id

HIST-20260714-0122

### original_question

建设一支 、 、 的人民军队，是实现“两个一百年”奋斗目标、实现中华民族伟大复兴的战略支撑

### question_type

choice

### options

A.听党指挥 B.骁勇善战C.能打胜仗 D.作风优良

### answer

ACD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0123

### item_id

HIST-20260714-0123

### original_question

实施乡村振兴战略。 问题是关系国计民生的根本性问题，必须始终把解决好“三农”问题作为全党工作重中之重

### question_type

choice

### options

A.农业B.农村 C.农民 D.农田

### answer

ABC

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0124

### item_id

HIST-20260714-0124

### original_question

巩固和发展爱国统一战线。坚持 ，支持民主党派按照中国特色社会主义参政党要求更好履行职能

### question_type

choice

### options

A.长期共存 B.互相监督 C.肝胆相照D.荣辱与共

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0125

### item_id

HIST-20260714-0125

### original_question

提高就业质量和人民收入水平，鼓励勤劳守法致富，就要

### question_type

choice

### options

A.扩大中等收入群体 B.增加低收入者收入；C.调节过高收入 D.取缔非法收入

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0126

### item_id

HIST-20260714-0126

### original_question

加强社会保障体系建设。坚持房子是用来住的、不是用来炒的定位，加快建立 的住房制度，让全体人民住有所居

### question_type

choice

### options

A.多主体供给 B.多渠道保障C.租购并举 D.多部门监管

### answer

ABC

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0127

### item_id

HIST-20260714-0127

### original_question

加强社会治理制度建设，完善党委领导、政府负责、社会协同、公众参与、法治保障的社会治理体制，提高社会治理 水平

### question_type

choice

### options

A.社会化 B.法治化 C.智能化 D.专业化

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0128

### item_id

HIST-20260714-0128

### original_question

必须坚持 、 、 为主的方针，形成节约资源和保护环境的空间格局、产业结构、生产方式、生活方式，还自然以宁静、和谐、美丽

### question_type

choice

### options

A.事先预防 B.节约优先 C.保护优先 D.自然恢复

### answer

BCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0129

### item_id

HIST-20260714-0129

### original_question

构建市场导向的绿色技术创新体系，发展绿色金融，壮大

### question_type

choice

### options

A.节能环保产业 B.清洁生产产业；C.绿色科技产业 D.清洁能源产业

### answer

ABD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0130

### item_id

HIST-20260714-0130

### original_question

倡导简约适度、绿色低碳的生活方式，反对奢侈浪费和不合理消费，开展创建节约型机关、 、 、 、 等行动

### question_type

choice

### options

A.绿色家庭 B.绿色学校 C.绿色社区 D.绿色城市 E.绿色出行

### answer

ABCE

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0131

### item_id

HIST-20260714-0131

### original_question

提高污染排放标准，强化排污者责任，健全 、 、 等制度

### question_type

choice

### options

A.环保信用评价 B.污染企业备案；C.信息强制性披露 D.严惩重罚

### answer

ACD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0132

### item_id

HIST-20260714-0132

### original_question

完成 、 、 三条控制线划定工作

### question_type

choice

### options

A.生态保护红线 B.永久基本农田；C.城镇开发边界 D.国土绿化面积

### answer

ABC

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0133

### item_id

HIST-20260714-0133

### original_question

保持香港、澳门长期繁荣稳定，必须全面准确贯彻 的方针

### question_type

choice

### options

A.“一国两制”B.“港人治港” C.“澳人治澳”D.高度自治

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0134

### item_id

HIST-20260714-0134

### original_question

要支持香港、澳门融入国家发展大局，以 、 、 等为重点，全面推进内地同香港、澳门互利合作

### question_type

choice

### options

A.粤港澳大湾区建设 B.粤港澳合作；C.粤港澳政府合作 D.泛珠三角区域合作

### answer

ABD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0135

### item_id

HIST-20260714-0135

### original_question

中国将高举 、 、 、 的旗帜，恪守维护世界和平、促进共同发展的外交政策宗旨

### question_type

choice

### options

A.和平 B.发展C.合作 D.共赢E.互惠

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0136

### item_id

HIST-20260714-0136

### original_question

坚定不移在和平共处五项原则基础上发展同各国的友好合作，推动建设 、 、 的新型国际关系

### question_type

choice

### options

A.相互尊重 B.公平正义(C.互不干涉 D.合作共赢

### answer

ABD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0137

### item_id

HIST-20260714-0137

### original_question

世界正处于大发展大变革大调整时期，和平与发展仍然是时代主题。 、 、 、 深入发展

### question_type

choice

### options

A.世界多极化 B.经济全球化 C.社会信息化 D.文化多样化；E.治理民主化

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0138

### item_id

HIST-20260714-0138

### original_question

积极促进“一带一路”国际合作，努力实现 、 、 、 、 ，打造国际合作新平台，增添共同发展新动力

### question_type

choice

### options

A.政策沟通 B.设施联通 C.贸易畅通 D.人员互通；E.资金融通 F.民心相通

### answer

ABCEF

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0139

### item_id

HIST-20260714-0139

### original_question

要深刻认识党面临的 的长期性和复杂性

### question_type

choice

### options

A.执政考验 B.改革开放考验C.市场经济考验 D.生态保护考验；E.外部环境考验

### answer

ABCE

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0140

### item_id

HIST-20260714-0140

### original_question

新时代党的建设总要求是

### question_type

choice

### options

A.坚持和加强党的全面领导，坚持党要管党、全面从严治党；B.以加强党的长期执政能力建设、先进性和纯洁性建设为主线，以党的政治建设为统领，以坚定理想信念宗旨为根基，以调动全党积极性、主动性、创造性为着力点；C.全面推进党的政治建设、思想建设、组织建设、作风建设、纪律建设；D.把制度建设贯穿其中，深入推进反腐败斗争，不断提高党的建设质量；E.把党建设成为始终走在时代前列、人民衷心拥护、勇于自我革命、经得起各种风浪考验、朝气蓬勃的马克思主义执政党

### answer

ABCDE

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0141

### item_id

HIST-20260714-0141

### original_question

领导十三亿多人的社会主义大国，我们党既要政治过硬，也要本领高强。要

### question_type

choice

### options

A.增强学习本领，增强政治领导本领；B.增强改革创新本领，增强科学发展本领；C.增强依法执政本领，增强群众工作本领；D.增强狠抓落实本领，增强驾驭风险本领

### answer

ABCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0142

### item_id

HIST-20260714-0142

### original_question

以 、 、 、 、 ,把党内和党外、国内和国外各方面优秀人才集聚到党和人民的伟大奋斗中来

### question_type

choice

### options

A.识才的慧眼 B.敬才的风度 C.爱才的诚意 D.用才的胆识；E.容才的雅量F.聚才的良方

### answer

ACDEF

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0143

### item_id

HIST-20260714-0143

### original_question

青年兴则国家兴，青年强则国家强。青年一代 、 、 ，国家就有前途，民族就有希望

### question_type

choice

### options

A.有品德B.有理想 C.有本领D.有担当

### answer

BCD

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable

## HIST-20260714-0144

### item_id

HIST-20260714-0144

### original_question

全党全国各族人民要紧密团结在党中央周围，高举中国特色社会主义伟大旗帜，锐意进取，埋头苦干，为实现推进现代化建设、完成祖国统一、维护世界和平与促进共同发展三大历史任务，为 继续奋斗！

### question_type

choice

### options

A.决胜全面建成小康社会；B.夺取新时代中国特色社会主义伟大胜利；C.全面建成社会主义现代化强国；D.实现中华民族伟大复兴的中国梦；E.实现人民对美好生活的向往

### answer

ABDE

### explanation



### source_file

2-07【十九大】   报告核心100题  （★★★★★）.docx

### source_pdf_file

2-07【十九大】   报告核心100题  （★★★★★）.pdf

### source_type

historical_policy

### historical

true

### real_exam

false

### counselor_exam_relevance

relevant

### time_sensitivity

true

### answer_reliability

source_explicit

### authority_scope

source-period only; not current policy authority

### processing_status

usable
