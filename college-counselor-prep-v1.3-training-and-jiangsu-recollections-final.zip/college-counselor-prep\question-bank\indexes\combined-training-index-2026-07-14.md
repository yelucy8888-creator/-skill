# Combined training and reference index — 2026-07-14

## Dedicated banks

| Bank | Count | `real_exam` | Scope |
|---|---:|---|---|
| `training_question_bank` | 2181 | false | Core knowledge, fill-in, short-answer and case training |
| `writing_reference_bank` | 35 | false | Blog/article and official-document writing examples |
| `historical_policy_bank` | 144 | false | Historical terms and historical policy专题; not current authority |

## Sources

- Training sources: 2-01, 2-02, 2-03, 2-05, 2-08, 2-09, 2-10, 2-11, 2-12.
- Writing references: 2-06 (20 examples) and 2-13 (15 examples).
- Historical sources: 2-04 and 2-07.
- Paired PDFs are retained as provenance evidence; Word is the primary extraction source.

## Isolation

The default `real_exam` retrieval path must not include any record whose `source_type` is `training_material`, `writing_reference`, or `historical_policy`.
