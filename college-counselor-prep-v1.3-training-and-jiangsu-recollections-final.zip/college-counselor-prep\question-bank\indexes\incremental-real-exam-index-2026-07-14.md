# Incremental real-exam index — 2026-07-14

This index covers the Word-first import from `C:\Users\Administrator\Desktop\第3章 全国真题`. The paired PDF is provenance evidence; the Word file is the primary text source.

| question type | new usable | output file |
|---|---:|---|
| 选择题 | 390 | `question-bank/usable/objective/real-exam-choice-2026-07-14.md` |
| 判断题 | 25 | `question-bank/usable/objective/real-exam-judgment-2026-07-14.md` |
| 填空题 | 135 | `question-bank/usable/objective/real-exam-fill-blank-2026-07-14.md` |
| 名词解释题 | 19 | `question-bank/usable/subjective/real-exam-term-definition-2026-07-14.md` |
| 简答题 | 392 | `question-bank/usable/subjective/real-exam-short-answer-2026-07-14.md` |
| 论述题 | 243 | `question-bank/usable/subjective/real-exam-essay-2026-07-14.md` |
| 案例分析题 | 251 | `question-bank/usable/case-analysis/real-exam-case-analysis-2026-07-14.md` |
| 结构化面试题 | 328 | `question-bank/usable/structured-interview/real-exam-structured-interview-2026-07-14.md` |
| 公文写作题 | 83 | `question-bank/usable/public-writing/real-exam-public-writing-2026-07-14.md` |
| 混合题型 | 14 | `question-bank/usable/mixed/real-exam-mixed-2026-07-14.md` |
| **合计** | **1880** | — |

All imported records retain Word/PDF filenames, inferred metadata boundaries, blank answers when absent, and `not_provided` answer reliability. See `reports/incremental-word-import-2026-07-14/` for manifests, pairing, duplicate, and admission reports.
