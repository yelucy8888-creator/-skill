# Jiangsu recollection index — 2026-07-14

- New usable `real_exam` recollection records: 32.
- `real_exam` total after update: 12593.
- Province: 江苏省.
- Source reliability: medium; `memory_version=true`; answers and explanations blank.
- 9 source files admitted; exact duplicates were suppressed and mapped in `reports/combined-training-and-jiangsu-recovery-2026-07-14/jiangsu-duplicate-report.md`.
- Remaining review: `3.2 【江苏省】29校真题.docx`; Word extraction has zero text runs, so no question is fabricated.

## Admission criteria

Only semantically complete, independently answerable prompts with traceable Word/PDF provenance were admitted. Recollections must not be described as official strict exam originals.
