# Real-exam review layer — 2026-07-14

Nine Jiangsu recollection Word files were recovered into real_exam usable with memory_version=true. One file remains review-only: `3.2 【江苏省】29校真题.docx`, because Word extraction returned zero text runs.
