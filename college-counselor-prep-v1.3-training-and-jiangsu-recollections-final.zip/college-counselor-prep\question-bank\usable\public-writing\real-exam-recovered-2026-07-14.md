# Recovered Jiangsu recollection real exams — 2026-07-14

Memory version; answers intentionally blank.

## REAL-20260714-1892

### year

2022

### province

江苏省

### school

南京农业大学

### exam_type

written_exam

### question_type

public_writing

### original_question

根据材料，写一篇“我为青年代言”的演讲稿，600字以上

### answer


### explanation


### source_word_file

2022年江苏省南京农业大学辅导员笔试真题.docx

### source_pdf_file

2022年江苏省南京农业大学辅导员笔试真题.pdf

### source_type

written_exam_recollection

### real_exam

true

### memory_version

true

### source_reliability

medium

### processing_status

usable

## REAL-20260714-1902

### year

2022

### province

江苏省

### school

无锡学院

### exam_type

written_exam

### question_type

public_writing

### original_question

(25分)如何缓解学生的就业压力，写600字的博文

### answer


### explanation


### source_word_file

2022年江苏省无锡学院辅导员笔试真题.docx

### source_pdf_file

2022年江苏省无锡学院辅导员笔试真题.pdf

### source_type

written_exam_recollection

### real_exam

true

### memory_version

true

### source_reliability

medium

### processing_status

usable

## REAL-20260714-1907

### year

2022

### province

江苏省

### school

无锡职业技术学院

### exam_type

written_exam

### question_type

public_writing

### original_question

习总书记一段话，请以“疫情期间，辅导员如何做好学生管理工作”为主题，写一篇博文，体裁不限，600字左右

### answer


### explanation


### source_word_file

2022年江苏省无锡职业技术学院辅导员笔试真题.docx

### source_pdf_file

2022年江苏省无锡职业技术学院辅导员笔试真题.pdf

### source_type

written_exam_recollection

### real_exam

true

### memory_version

true

### source_reliability

medium

### processing_status

usable
