# Excluded correction report

- Files moved out of excluded: 13
- New destinations: training_question_bank, writing_reference_bank, historical_policy_bank
- All retain real_exam=false and counselor_exam_relevance=relevant.
