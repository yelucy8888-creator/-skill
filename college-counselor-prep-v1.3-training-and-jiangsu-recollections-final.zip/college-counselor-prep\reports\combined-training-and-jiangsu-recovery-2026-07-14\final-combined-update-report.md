# Final combined update report

- Previous version: v1.2.0-word-real-exams
- New version: v1.3.0-training-and-jiangsu-recollections
- real_exam usable: 12561 -> 12593
- New Jiangsu recollection real_exam usable: 32
- Remaining real_exam review files: 1
- training usable added: 2181
- historical policy records: 144
- writing reference records: 35
- Overall searchable total: 14953
- Exact duplicate records this run: 407
- Training source files reclassified from excluded: 13
- Unresolved: 3.2 Jiangsu 29-school Word/PDF recovery; no text fabricated.
