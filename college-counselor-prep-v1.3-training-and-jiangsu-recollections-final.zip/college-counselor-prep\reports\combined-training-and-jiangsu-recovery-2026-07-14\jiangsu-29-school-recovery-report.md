# Jiangsu 29-school recovery report

- zip_entries: 958
- document_xml_bytes: 1261351
- text_runs: 0
- tables: 38
- drawings: 958
- textboxes: 0
- media: 936
- pdf: 3.2 【江苏省】29校真题.pdf
- Result: not imported; no text may be fabricated from school compilation filename.
