# Jiangsu recollection extraction report

- Recovered question counts by type: {'short_answer': 9, 'case_analysis': 10, 'structured_interview': 6, 'public_writing': 3, 'essay': 4}
- No answer or explanation was added.
- Short but semantically complete recollection prompts were accepted.

## By source

- `2021江苏经贸职业技术学院.docx`: 3
- `2022年江苏师范大学辅导员笔试真题.docx`: 4
- `2022年江苏省南京信息工程大学辅导员面试真题.docx`: 3
- `2022年江苏省南京农业大学辅导员笔试真题.docx`: 2
- `2022年江苏省南京航空航天大学辅导员笔试真题.docx`: 4
- `2022年江苏省无锡学院辅导员笔试真题.docx`: 6
- `2022年江苏省无锡职业技术学院辅导员笔试真题.docx`: 5
- `2022年江苏省淮阴工学院辅导员笔试真题.docx`: 2
- `2022年江苏第二师范学院辅导员面试真题.docx`: 3
