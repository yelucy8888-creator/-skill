# Jiangsu remaining review

- Remaining file: `3.2 【江苏省】29校真题.docx`
- Reason: Word extraction returned zero text runs/paragraphs; school-level sections cannot be safely recovered.
- Action: keep review; manual XML/media/PDF inspection or fresh conversion/OCR required.
