# Jiangsu source-file review

- Review files inspected: 10
- Recollection files recovered: 9
- 29-school compilation still review: 1
- Recovered records: 32
- Recovered records are marked memory_version=true, source_reliability=medium, and answers blank.

## Recovered source counts

- `2021江苏经贸职业技术学院.docx`: 3
- `2022年江苏师范大学辅导员笔试真题.docx`: 4
- `2022年江苏省南京信息工程大学辅导员面试真题.docx`: 3
- `2022年江苏省南京农业大学辅导员笔试真题.docx`: 2
- `2022年江苏省南京航空航天大学辅导员笔试真题.docx`: 4
- `2022年江苏省无锡学院辅导员笔试真题.docx`: 6
- `2022年江苏省无锡职业技术学院辅导员笔试真题.docx`: 5
- `2022年江苏省淮阴工学院辅导员笔试真题.docx`: 2
- `2022年江苏第二师范学院辅导员面试真题.docx`: 3

## Admission rule

Only prompts with a complete meaning, independent answerability, and traceable Word/PDF provenance were admitted. Exact duplicates were suppressed without resolving answer conflicts.
