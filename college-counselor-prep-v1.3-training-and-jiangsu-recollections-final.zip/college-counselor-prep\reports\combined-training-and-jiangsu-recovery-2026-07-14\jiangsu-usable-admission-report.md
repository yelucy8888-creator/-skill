# Jiangsu usable admission report

- New real_exam usable: 32
- Admission: semantically complete, independently answerable, traceable Word/PDF source, recollection explicitly labeled.
