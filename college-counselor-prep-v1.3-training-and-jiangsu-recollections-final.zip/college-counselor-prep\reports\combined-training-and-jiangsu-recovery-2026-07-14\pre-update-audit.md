# Pre-update audit

- Version: v1.2.0-word-real-exams
- real_exam usable: 12561
- real_exam review files: 10
- training usable: 0
- training review: 0
- writing reference: 0
- historical: 0
- duplicate records: 66
- excluded files: 13
- overall searchable: 12561
- Primary data format: Markdown with per-record fields; CSV manifests support provenance.
- Reusable script: `incremental_word_import.py` for Word OOXML reading; this run uses `combined_repair.py`.
