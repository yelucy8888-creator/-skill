# Retrieval isolation test report

- real_exam=true must exclude training_material, writing_reference, and historical_policy.
- training queries must use training_question_bank and label source_type.
- writing-reference queries must use writing_reference_bank and keep whole examples.
- historical queries must carry time-sensitivity warnings.
- Recollection records must display memory_version=true.
