# Time-sensitive question report

Historical/time-sensitive sources: 2-04 and 2-07. Policy/regulation-sensitive training sources include 2-01, 2-02, 2-08, 2-10, 2-11, and 2-12. These are not current-policy authority and require current-source verification.
