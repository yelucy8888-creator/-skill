# Training extraction summary

- Training usable: 2181
- Historical policy: 144
- By type: {'choice': 1549, 'fill_blank': 73, 'short_answer': 292, 'case_analysis': 267}
- Historical by type: {'term_definition': 45, 'choice': 99}
- Writing references: 35

## Training usable by source

- `2-01【选择】核心300题（★★★★★）.docx`: 286
- `2-02【填空】核心300题（★★★★★）.docx`: 73
- `2-03【简答论述】核心200题（★★★★★）.docx`: 292
- `2-05【案例分析】精选50题（★★★★★）.docx`: 267
- `2-08【高等教育学】200题.docx`: 569
- `2-09【高等教育心理学】180题.docx`: 538
- `2-10【心理健康与心理调适】140题.docx`: 21
- `2-11【高等教育政策与法规】88题（★★★）.docx`: 83
- `2-12【教师职业道德】50题 （★★★）.docx`: 52

## Historical policy by source

- `2-04【名词解释】核心50题.docx`: 45
- `2-07【十九大】   报告核心100题  （★★★★★）.docx`: 99
