# Training reclassification report

The 13 files below are preparation materials rather than school/year-specific recruitment exam papers. They are excluded from real_exam but preserved in dedicated banks.

- `2-01【选择】核心300题（★★★★★）.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-02【填空】核心300题（★★★★★）.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-03【简答论述】核心200题（★★★★★）.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-04【名词解释】核心50题.docx` → `historical_policy_bank`；real_exam=false；历史政策/历史专题资料，缺少具体招聘考试来源，且不能作为现行政策权威。
- `2-05【案例分析】精选50题（★★★★★）.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-06【博文写作】范文20例.docx` → `writing_reference_bank`；real_exam=false；范文/公文样例，提供表达与结构参考，不是招聘考试卷。
- `2-07【十九大】   报告核心100题  （★★★★★）.docx` → `historical_policy_bank`；real_exam=false；历史政策/历史专题资料，缺少具体招聘考试来源，且不能作为现行政策权威。
- `2-08【高等教育学】200题.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-09【高等教育心理学】180题.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-10【心理健康与心理调适】140题.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-11【高等教育政策与法规】88题（★★★）.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-12【教师职业道德】50题 （★★★）.docx` → `training_question_bank`；real_exam=false；按知识点或题型组织的核心题库/案例题库，非特定学校、年份招聘试卷。
- `2-13【公文写作】范文15例.docx` → `writing_reference_bank`；real_exam=false；范文/公文样例，提供表达与结构参考，不是招聘考试卷。
