# Validation report

- Old v1.2 question files were not overwritten.
- Original Word/PDF files were not modified.
- Training materials are no longer excluded-only; they are classified in dedicated banks.
- Recovered Jiangsu records have traceable Word/PDF sources and blank answers.
- 3.2 compilation remains review.
