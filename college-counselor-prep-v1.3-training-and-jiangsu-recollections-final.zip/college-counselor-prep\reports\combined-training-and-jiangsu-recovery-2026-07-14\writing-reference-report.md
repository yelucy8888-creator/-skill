# Writing reference report

- Writing reference records: 35
- Sources: 2-06 blog/article examples; 2-13 official-document examples
- real_exam: false
- These records are preserved as whole writing references, not split into ordinary exam questions.
