# Excluded Files Report

- `raw-inbox/`：原始待分类资料，不进入交付版
- `raw-materials/`：原始 PDF/Word 等资料，不进入交付版
- `converted-text/`：Word 转换件和转换日志，不进入交付版
- `full-extraction/`：工程备份全量原始题库正文，不进入默认交付版
- `final-layered-question-bank/`：旧分层目录已被 final-usable-question-bank 替代
- `safe-core/review/archive/duplicate 旧目录`：不再作为最终交付结构
