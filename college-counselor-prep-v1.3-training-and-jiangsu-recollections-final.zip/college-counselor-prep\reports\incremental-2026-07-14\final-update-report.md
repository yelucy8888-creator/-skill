# 最终增量更新报告

- 更新前版本：v1.0-usable-question-bank
- 更新后版本：v1.1.0-incremental-real-exam-review
- 新增原始 PDF：81
- individual_real_exam：49
- provincial_compilation：18
- unknown_real_exam：2
- training_material / excluded：12
- 新增题目进入 usable：0
- 新增来源进入 review：69
- 新增 archive：0
- 新增 duplicate：0
- 新增 excluded：12
- 更新前 usable：10681
- 更新后 usable：10681
- 风险：PDF 原生文本探测不等同于正确抽取；OCR 不可用；v1.0 未保留完整来源注册表；本批未将任何未核验题目写入 usable。
