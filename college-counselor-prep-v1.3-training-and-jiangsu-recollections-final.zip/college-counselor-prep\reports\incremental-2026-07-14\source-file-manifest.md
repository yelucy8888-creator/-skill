# 增量源文件清单（2026-07-14）

源目录：`C:\Users\Administrator\Desktop\第3章 全国真题`
原始 PDF 总数：81

|来源类型|数量|
|---|---:|
|individual_real_exam|49|
|provincial_compilation|18|
|training_material|12|
|unknown_real_exam|2|

## 处理结论

本批未将任何题目直接写入 usable。训练资料按 excluded 记录；真题 PDF 先按来源和文本层进入 review，待具备可靠 PDF/OCR 提取能力并人工核验后再题目级入库。

更新前 usable 题库统计：v1.0 报告口径 10681 题；本地可扫描 Markdown 文件：10 个。
