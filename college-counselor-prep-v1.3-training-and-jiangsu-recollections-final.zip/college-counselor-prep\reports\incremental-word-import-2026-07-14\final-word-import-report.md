# Final Word import report

- Previous version: v1.1.0-incremental-real-exam-review
- New version: v1.2.0-word-real-exams
- Word files: 82
- .docx files: 82
- .doc files: 0
- PDF files: 81
- Word-PDF relationships: 82
- Unique matched PDFs: 81
- Extracted candidate questions: 1946
- Exact duplicates: 66
- Near-duplicate review: 0
- New usable: 1880
- New review: 10
- New excluded: 13
- Usable before: 10681
- Usable after: 12561
- Important boundary: no answer or explanation was fabricated.
