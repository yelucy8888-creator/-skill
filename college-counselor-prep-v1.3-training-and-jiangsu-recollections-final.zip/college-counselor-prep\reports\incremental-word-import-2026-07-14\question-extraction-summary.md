# Question extraction summary

- Extracted candidate questions: 1880
- Exact duplicates: 66
- Near-duplicate review: 0

- 公文写作题: 83
- 判断题: 25
- 名词解释题: 19
- 填空题: 135
- 案例分析题: 251
- 混合题型: 14
- 简答题: 392
- 结构化面试题: 328
- 论述题: 243
- 选择题: 390
