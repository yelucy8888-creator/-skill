# Reclassification report

Training-material files remain excluded based on their explicit training/core-bank naming. No file was reclassified as a real exam solely because it contained the word 真题.
