# Review admission report

- Near-duplicate candidates: 0
- Files without extractable numbered question blocks: 10
- Training files excluded: 13

Review records are not default search results.
