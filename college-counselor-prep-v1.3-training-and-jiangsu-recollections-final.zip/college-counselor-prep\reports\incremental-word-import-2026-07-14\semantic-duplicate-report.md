# Semantic duplicate report

Near-duplicate candidates are retained for review and are not silently deleted.


