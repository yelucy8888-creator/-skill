# Source overlap report

Word is the primary extraction source and paired PDF is retained as provenance. Exact duplicate candidates were checked against all Markdown files under `question-bank/`.
