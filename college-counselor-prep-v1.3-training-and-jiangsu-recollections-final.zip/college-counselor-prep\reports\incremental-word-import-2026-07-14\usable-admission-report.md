# Usable admission report

- New usable questions: 1880
- Admission rule: complete Word question block, traceable Word source, and no exact/near duplicate detected.
- Answers and explanations remain blank when absent in source.
