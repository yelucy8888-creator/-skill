# Validation report — 2026-07-14 Word import

- New incremental files: 10
- New question records: 1,880
- Global question IDs: 1,880; unique IDs: 1,880
- Jiangsu real-exam search: passed
- Shandong real-exam search: passed
- Specific school/year source search: passed (`2020年江苏科技大学辅导员笔试真题`)
- Training-material filename leakage into new usable files: 0
- Word manifest rows: 82; empty SHA-256 fields: 0
- Unique matched PDFs: 81
- Existing v1.1 usable Markdown files changed: 0
- Answer conflict auto-resolution: none; absent answers remain blank
- Original Word/PDF source files: not modified
