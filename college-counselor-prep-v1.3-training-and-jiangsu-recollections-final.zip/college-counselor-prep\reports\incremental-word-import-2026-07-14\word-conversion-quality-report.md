# Word conversion quality

All `.docx` files were read from OOXML directly; no `.doc` files were present. Files with readable paragraphs/tables are marked high for text extraction, but question-level answer reliability remains not_provided when Word supplied no answer.
