# Word extraction errors

- 2021江苏经贸职业技术学院.docx: paragraph_or_table_lines=11; extracted_items=0
- 2022年江苏师范大学辅导员笔试真题.docx: paragraph_or_table_lines=12; extracted_items=0
- 2022年江苏省南京信息工程大学辅导员面试真题.docx: paragraph_or_table_lines=4; extracted_items=0
- 2022年江苏省南京农业大学辅导员笔试真题.docx: paragraph_or_table_lines=10; extracted_items=0
- 2022年江苏省南京航空航天大学辅导员笔试真题.docx: paragraph_or_table_lines=5; extracted_items=0
- 2022年江苏省无锡学院辅导员笔试真题.docx: paragraph_or_table_lines=7; extracted_items=0
- 2022年江苏省无锡职业技术学院辅导员笔试真题.docx: paragraph_or_table_lines=6; extracted_items=0
- 2022年江苏省淮阴工学院辅导员笔试真题.docx: paragraph_or_table_lines=10; extracted_items=0
- 2022年江苏第二师范学院辅导员面试真题.docx: paragraph_or_table_lines=4; extracted_items=0
- 3.2 【江苏省】29校真题.docx: paragraph_or_table_lines=0; extracted_items=0
