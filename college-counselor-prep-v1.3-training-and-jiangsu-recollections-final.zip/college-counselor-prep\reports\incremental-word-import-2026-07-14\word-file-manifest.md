# Word file manifest

Word files: 82
PDF files: 81

|file_id|filename|source_type|matched_pdf|processing_status|
|---|---|---|---|---|
|WORD-20260714-001|2-01【选择】核心300题（★★★★★）.docx|training_material|yes|excluded_training_material|
|WORD-20260714-002|2-02【填空】核心300题（★★★★★）.docx|training_material|yes|excluded_training_material|
|WORD-20260714-003|2-03【简答论述】核心200题（★★★★★）.docx|training_material|yes|excluded_training_material|
|WORD-20260714-004|2-04【名词解释】核心50题.docx|training_material|yes|excluded_training_material|
|WORD-20260714-005|2-05【案例分析】精选50题（★★★★★）.docx|training_material|yes|excluded_training_material|
|WORD-20260714-006|2-06【博文写作】范文20例.docx|training_material|yes|excluded_training_material|
|WORD-20260714-007|2-07【十九大】   报告核心100题  （★★★★★）.docx|training_material|yes|excluded_training_material|
|WORD-20260714-008|2-08【高等教育学】200题.docx|training_material|yes|excluded_training_material|
|WORD-20260714-009|2-09【高等教育心理学】180题.docx|training_material|yes|excluded_training_material|
|WORD-20260714-010|2-10【心理健康与心理调适】140题.docx|training_material|yes|excluded_training_material|
|WORD-20260714-011|2-11【高等教育政策与法规】88题（★★★）.docx|training_material|yes|excluded_training_material|
|WORD-20260714-012|2-12【教师职业道德】50题 （★★★）.docx|training_material|yes|excluded_training_material|
|WORD-20260714-013|2-13【公文写作】范文15例.docx|training_material|yes|excluded_training_material|
|WORD-20260714-014|2019-2016 年江苏省南京财经大学红山学院笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-015|2019-2017年江苏省扬州大学广陵学院笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-016|2020,2018,2016江苏省常熟理工学院辅导员笔试面试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-017|2020年江苏师范大学科文学院辅导员笔试面试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-018|2020年江苏省常熟理工大学辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-019|2020年江苏科技大学辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-020|2021,2015年江苏南京铁道职业技术学院辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-021|2021,2015年江苏省无锡工艺职业技术笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-022|2021,2016年江苏省南京邮电大学辅导员招聘笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-023|2021,2018年江苏省徐州工业职业技术学院辅导员笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-024|2021,2019,2017-2016年江苏南京审计学院辅导员笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-025|2021,2019年江苏省宿迁学院辅导员笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-026|2021-2018,某年江苏省南京师范大学辅导员笔试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-027|2021-2019,2017年江苏南京航空航天大学辅导员笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-028|2021-2020,2017年江苏省河海大学辅导员招聘笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-029|2021年江苏师范大学辅导员考试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-030|2021江苏工程职业技术学院辅导员考试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-031|2021江苏建筑职业技术学院辅导员考试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-032|2021江苏海事职业学院辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-033|2021江苏海事职业技术学院辅导员考试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-034|2021江苏科技大学辅导员考试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-035|2021江苏经贸职业技术学院.docx|unknown_real_exam|yes|review_no_question_blocks|
|WORD-20260714-036|2022-2015江苏省苏州大学辅导员岗位笔试面试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-037|2022-2020,2016年江苏第二师范学院辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-038|2022-2021年江苏省南京工业职业技术大学辅导员笔试面试题库.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-039|2022年中国矿业大学辅导员笔试真题（考生回忆版）.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-040|2022年江苏城乡建设职业学院辅导员面试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-041|2022年江苏大学辅导员笔试真题(1).docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-042|2022年江苏师范大学辅导员笔试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-043|2022年江苏师范大学辅导员笔试真题（2）.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-044|2022年江苏省南京信息工程大学辅导员面试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-045|2022年江苏省南京农业大学辅导员笔试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-046|2022年江苏省南京农业大学辅导员笔试面试题目.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-047|2022年江苏省南京航空航天大学辅导员笔试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-048|2022年江苏省南通师范高等专科学校辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-049|2022年江苏省宿迁学院辅导员面试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-050|2022年江苏省徐州医科大学辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-051|2022年江苏省扬州大学辅导员面试真题 (2).docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-052|2022年江苏省扬州工业职业技术学院辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-053|2022年江苏省无锡学院辅导员笔试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-054|2022年江苏省无锡职业技术学院辅导员笔试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-055|2022年江苏省淮阴工学院辅导员笔试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-056|2022年江苏省盐城幼儿师范高等专科学校辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-057|2022年江苏省苏州大学辅导员 面试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-058|2022年江苏科技大学辅导员笔试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-059|2022年江苏第二师范学院辅导员面试真题.docx|individual_real_exam|yes|review_no_question_blocks|
|WORD-20260714-060|2022江苏大学辅导员面试真题.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-061|2023年江苏食品药品职业学院辅导员考试真题20230311.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-062|3-01【山东省】30校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-063|3-02【江苏省】29校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-064|3-03【河南省】23校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-065|3-04【京津冀】18校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-066|3-05【湖北省】13校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-067|3-06【浙江省】13校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-068|3-07【广东省】13校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-069|3-08【陕甘蒙】13校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-070|3-09【贵桂琼】12校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-071|3-10【东三省】10校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-072|3-11【川渝云】10校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-073|3-12【安徽省】10校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-074|3-13【福建省】7校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-075|3-14【湖南省】8校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-076|3-15【江西省】5校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-077|3-16【山西省】5校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-078|3-17【上海市】2校真题.docx|provincial_compilation|yes|extracted_for_import|
|WORD-20260714-079|3.2 【江苏省】29校真题.docx|provincial_compilation|yes|review_no_question_blocks|
|WORD-20260714-080|江苏大学2018年辅导员招聘笔试最新.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-081|江苏大学辅导员考试2015真题-2beba86330a5.docx|individual_real_exam|yes|extracted_for_import|
|WORD-20260714-082|江苏大学辅导员考试2015真题.docx|individual_real_exam|yes|extracted_for_import|
