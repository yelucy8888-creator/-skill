# Word-PDF pairing report

- Word files: 82
- PDF files: 81
- Word-PDF relationships: 82
- Unique matched PDFs: 81
- Unmatched Word: 0
- Unmatched PDF: 0
- Duplicate Word references to the same PDF: 1

Pairing used exact same stem first; only a unique conservative prefix fallback was allowed. A duplicate Word conversion is retained as a source record but must not create duplicate questions.
