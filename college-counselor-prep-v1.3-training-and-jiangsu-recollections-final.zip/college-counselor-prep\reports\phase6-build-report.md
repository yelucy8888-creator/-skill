# Phase 6 Build Report

- 生成文件：SKILL.md、README.md、quick-start.md、source-disclaimer.md、version.md、delivery-checklist.md、references、question-bank、templates、rubrics、workflows、reports。
- 复制 processed 文件：政策知识卡、当前时政、来源可靠性报告、usable-question-bank、题库索引与报告。
- 新生成说明文件：README、quick-start、source-disclaimer、question-bank usage/risk、version、delivery checklist、reports。
- 默认题库位置：question-bank/usable
- 是否生成 SKILL.md：是
- 是否生成 README：是
- 是否生成 quick-start：是
- 是否生成 source-disclaimer：是
- 是否可以进入第七阶段测试：是
