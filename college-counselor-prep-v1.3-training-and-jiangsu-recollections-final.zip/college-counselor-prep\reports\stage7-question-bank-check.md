# Stage 7 Question Bank Check

|文件|是否存在|是否非空|格式基本一致|保留来源/题型/题干|人工核对标记|是否需要修复|修复结果|
|---|---|---|---|---|---|---|---|
|question-bank/usable/objective/choice-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/objective/judgment-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/objective/fill-blank-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/subjective/short-answer-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/subjective/essay-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/case-analysis/case-analysis-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/structured-interview/structured-interview-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/current-affairs/current-affairs-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/public-writing/public-writing-usable.md|是|是|是|是|是|否|通过|
|question-bank/usable/mixed/mixed-usable.md|是|是|是|是|是|否|通过|
