# Stage 7 Sample Task Test

|测试指令|是否被 Skill 覆盖|需要读取哪些文件|预期回答结构|是否存在风险|是否需要修复|修复结果|
|---|---|---|---|---|---|---|
|请给我制定一个30天高校辅导员备考计划。|是|workflows/daily-training-workflow.md；workflows/weekly-review-workflow.md|按周拆解政策、题库、案例、面试、公文和复盘任务|是，需提示题库来源和核对边界|否|通过|
|今日训练。|是|workflows/daily-training-workflow.md；question-bank/usable|给出当天训练任务和题型配比|是，需提示题库来源和核对边界|否|通过|
|从可用题库里抽10道选择题。|是|question-bank/usable/objective/choice-usable.md|列题、等待作答、再批改|是，需提示题库来源和核对边界|否|通过|
|从可用题库里抽5道填空题。|是|question-bank/usable/objective/fill-blank-usable.md|列题、保留答案或训练后展示|是，需提示题库来源和核对边界|否|通过|
|请讲解“辅导员岗位职责”。|是|references/counselor-core-policy-cards.md|岗位定位、职责、答题表达|是，需提示题库来源和核对边界|否|通过|
|请讲解“立德树人”。|是|references/counselor-core-policy-cards.md|政策含义、辅导员工作转化|是，需提示题库来源和核对边界|否|通过|
|请出一道心理危机案例分析题。|是|question-bank/usable/case-analysis；templates/case-analysis-template.md|给案例题和作答要求|是，需提示题库来源和核对边界|否|通过|
|请模拟高校辅导员结构化面试，一次只问一个问题。|是|question-bank/usable/structured-interview；workflows/mock-interview-workflow.md|逐题提问、追问、点评|是，需提示题库来源和核对边界|否|通过|
|请批改我的简答题答案。|是|rubrics/answer-grading-rules.md；templates/short-answer-template.md|评分、优点、问题、修改版|是，需提示题库来源和核对边界|否|通过|
|请批改我的案例分析答案。|是|rubrics/case-analysis-rubric.md|按定性、原因、措施、跟进批改|是，需提示题库来源和核对边界|否|通过|
|请复习2025-2026时政热点。|是|references/current-affairs-2025-2026.md；question-bank/usable/current-affairs|提示时效并分类复习|是，需提示题库来源和核对边界|否|通过|
|请练习一篇公文写作题。|是|question-bank/usable/public-writing；templates/public-writing-template.md|给文种任务和格式要求|是，需提示题库来源和核对边界|否|通过|
|请整理我的错题。|是|workflows/wrong-question-review-workflow.md|记录错因、考点、复习计划|是，需提示题库来源和核对边界|否|通过|
|请给我制定14天冲刺计划。|是|workflows/final-sprint-workflow.md|高频模块和每日任务|是，需提示题库来源和核对边界|否|通过|
|请说明这个题库的来源和风险。|是|source-disclaimer.md；question-bank/question-bank-risk-note.md|说明来源、风险和免责声明|是，需提示题库来源和核对边界|否|通过|
