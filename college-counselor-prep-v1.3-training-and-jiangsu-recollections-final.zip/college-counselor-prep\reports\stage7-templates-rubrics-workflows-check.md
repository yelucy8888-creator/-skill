# Stage 7 Templates Rubrics Workflows Check

|类别|文件|是否存在|是否非空|是否需要修复|修复结果|
|---|---|---|---|---|---|
|templates|short-answer-template.md|是|是|否|通过|
|templates|essay-answer-template.md|是|是|否|通过|
|templates|case-analysis-template.md|是|是|否|通过|
|templates|structured-interview-template.md|是|是|否|通过|
|templates|current-affairs-answer-template.md|是|是|否|通过|
|templates|public-writing-template.md|是|是|否|通过|
|templates|interview-expression-bank.md|是|是|否|通过|
|rubrics|written-exam-rubric.md|是|是|否|通过|
|rubrics|case-analysis-rubric.md|是|是|否|通过|
|rubrics|structured-interview-rubric.md|是|是|否|通过|
|rubrics|current-affairs-rubric.md|是|是|否|通过|
|rubrics|answer-grading-rules.md|是|是|否|通过|
|workflows|daily-training-workflow.md|是|是|否|通过|
|workflows|weekly-review-workflow.md|是|是|否|通过|
|workflows|mock-interview-workflow.md|是|是|否|通过|
|workflows|wrong-question-review-workflow.md|是|是|否|通过|
|workflows|case-analysis-training-workflow.md|是|是|否|通过|
|workflows|final-sprint-workflow.md|是|是|否|通过|
