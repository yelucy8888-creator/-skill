# Public Writing Template

先判断文种，再明确对象、目的、结构、语气和落款。不得编造具体通知来源。
