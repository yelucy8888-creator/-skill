# Version

## Incremental Word import 2026-07-14

- Version: `v1.2.0-word-real-exams`
- Word files: 82 `.docx`; PDF files: 81; unique matched PDFs: 81.
- New usable questions: 1,880.
- Exact duplicates: 66; file-level review: 10; training-material excluded: 13.
- Usable total: 10,681 → 12,561.
- Word is the primary extraction source; paired PDF is provenance evidence.
- No answer or explanation was fabricated.
- Detailed reports: `reports/incremental-word-import-2026-07-14/`.

## Incremental update 2026-07-14

- Version: `v1.1.0-incremental-real-exam-review`
- 81 source PDFs were registered from the actual source directory.
- 49 individual real-exam candidates, 18 provincial compilations, and 2 unknown real-exam candidates were placed in review.
- 12 training-material PDFs were excluded from the real-exam intake.
- New questions added to `question-bank/usable`: 0. The usable total remains 10681.
- No question, answer, school, year, or explanation was fabricated from filenames or failed extraction.
- Detailed audit files are in `reports/incremental-2026-07-14/`.

- 版本号：v1.0-usable-question-bank
- 版本名称：高校辅导员备考 Skill 可用题库交付版
- 生成日期：2026-07-09
- 主要功能：政策解释、笔试训练、案例分析、结构化面试、公文写作、时政复习、答案批改、错题复盘
- 默认题库：question-bank/usable
- 题库规模：10681 道
- 不包含：raw-materials、converted-text、full-extraction、final-layered-question-bank、旧 safe/review/archive/duplicate 分层目录
- 已知限制：9640 道题需要人工核对；判断题较少；混合题型较多；时政题有时效性风险
- v1.1 建议：补充判断题、继续拆分混合题型、人工核对高频题、更新最新招聘公告和时政资料

## 联合增量修复 2026-07-14

- Version: `v1.3.0-training-and-jiangsu-recollections`
- `real_exam` usable: 12561 → 12593；新增江苏真题回忆 32 条。
- `training_question_bank`: 2181 条；`writing_reference_bank`: 35 条；`historical_policy_bank`: 144 条。
- 13 个误列 excluded 的文件已分类保留，但均为 `real_exam=false`。
- 9 个江苏回忆来源文件完成准入；1 个 `3.2 【江苏省】29校真题.docx` 继续 review，未从文件名或不可读 Word 媒体中编造题目。
- 本轮精确重复抑制记录 407 条；答案冲突不自动裁决。
- 详细报告：`reports/combined-training-and-jiangsu-recovery-2026-07-14/`。
