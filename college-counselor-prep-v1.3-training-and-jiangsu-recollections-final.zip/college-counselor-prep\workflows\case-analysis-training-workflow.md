# Case Analysis Training Workflow

先独立作答，再按 rubric 批改并重写。
