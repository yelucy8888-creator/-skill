# Changelog

## v1.4 江苏 29 校来源修正 — 2026-07-14

- 将 `3-02【江苏省】29校真题.docx` 设为 `valid_extractable_source`、`recalled_exam_collection`、`江苏省`、`historical_exam`。
- 保留 `3.2 【江苏省】29校真题-2f83d1e0a315.docx.qkdownloading` 为 `excluded_by_user`，排除原因 `incomplete_download_file`；两个文件分别登记。
- 按 29 所学校、2015—2019 年、笔试/面试和题型字段拆分完整 DOCX。
- 新增 270 条去重后结构化记录：具体题目 216 条、题型概述 54 条；其中明确回忆真题 209 条、题型概述 54 条、公开考试复用 7 条。
- 增加 `recalled_real_exam`、`exam_outline`、`reused_public_exam_question`、`reference_material`、`unknown_authenticity` 真实性分层。
- 增加学校规范化字段，保留原文学校名；例如“江苏河海大学”规范为“河海大学”。
- 增加来源映射、学校/年份统计、精确去重、未决片段和最终记录统计报告。
