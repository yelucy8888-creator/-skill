# Delivery Checklist

- [x] SKILL.md 是否存在：是
- [x] README.md 是否存在：是
- [x] quick-start.md 是否存在：是
- [x] source-disclaimer.md 是否存在：是
- [x] version.md 是否存在：是
- [x] references 是否存在：是
- [x] question-bank/usable 是否存在：是
- [x] question-bank/indexes 是否存在：是
- [x] templates 是否存在：是
- [x] rubrics 是否存在：是
- [x] workflows 是否存在：是
- [x] reports 是否存在：是
- [x] raw-materials 是否未进入最终包：是
- [x] converted-text 是否未进入最终包：是
- [x] full-extraction 是否未进入最终包：是
- [x] final-layered-question-bank 是否未进入最终包：是
- [x] 是否说明题库风险：是
- [x] 是否说明需人工核对题：是
- [x] 是否说明时政时效性：是
- [x] 是否说明不能保证考试通过：是
- [x] 是否适合进入第七阶段测试：是
- [x] v1.4 补充知识目录是否存在：是
- [x] v1.4 面试/笔试训练题是否分层：是，525 道
- [x] v1.4 来源映射、去重和时效性报告是否存在：是
- [x] 溪溪状元笔记完整版是否避免未经核验 OCR：是
- [x] 江苏 29 校未完成下载文件是否明确排除：是，`excluded_by_user`
- [x] 溪溪通关密卷是否避免重复导入：是，v1.3 已收录
- [x] 江苏 29 校完整 DOCX 是否作为有效来源导入：是，270 条去重后记录
- [x] 江苏 29 校学校/年份/题型字段是否存在：是
- [x] 江苏回忆题真实性是否分层：是，五级 authenticity 分类
- [x] 旧江苏 `.qkdownloading` 临时文件是否仍单独排除：是，`incomplete_download_file`
- [x] 江苏来源统计、学校拆分和未决片段报告是否存在：是

## 统一题库风险提示

- 默认题库为 `question-bank/usable`。
- usable-question-bank 总题量为 10681 道。
- 需要人工核对但仍可使用的题目为 9640 道。
- 判断题数量较少，为 21 道；不要默认承诺高数量判断题训练。
- 时政专项题较多，为 5621 道；时政内容具有时效性。
- 混合题型较多，为 2571 道；适合综合训练和进一步拆分复盘。
- 本题库不是官方真题库。
- 培训资料不能当作官方依据。
- 真题回忆不能当作严格真题。
- 旧时政不得当作最新时政。
- 本 Skill 不能替代最新招聘公告。
- 本 Skill 不能保证考试通过。
- v1.4 补充训练题和知识卡属于培训/参考素材，不是官方真题或政策原文。

