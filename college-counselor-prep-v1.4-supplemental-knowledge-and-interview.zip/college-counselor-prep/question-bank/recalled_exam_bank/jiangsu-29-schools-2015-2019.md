# 江苏省 29 校高校辅导员招聘真题回忆结构化题库（v1.4）

本文件由可提取 DOCX `3-02【江苏省】29校真题.docx` 生成。资料主要来自考生回忆，覆盖 2015—2019 年，含部分题型概述、残缺题干、公务员公开题复用和参考性内容。所有记录均为 `historical_exam`，不得默认视为官方原卷或当前政策答案。


## J29-00001｜江南大学｜2019｜short_answer


### record_id

J29-00001

### question

中国共产党三大历史功绩是什么

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第36行｜三、简答题20分｜原题号1

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00002｜江南大学｜2019｜short_answer


### record_id

J29-00002

### question

高校办学的四个服务是什么

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第36行｜三、简答题20分｜原题号2

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00003｜江南大学｜2019｜short_answer


### record_id

J29-00003

### question

五位一体和四个全面是什么

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第36行｜三、简答题20分｜原题号3

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00004｜江南大学｜2019｜short_answer


### record_id

J29-00004

### question

习近平在全国教育讲话中，如何培养社会主义建设者和接班人，在什么上下功夫

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第36行｜三、简答题20分｜原题号4

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00005｜江南大学｜2019｜essay_question


### record_id

J29-00005

### question

美国封杀中兴，对于提高科技能力可以从几方面展开。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第41行｜四、论述题20分｜原题号1

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00006｜江南大学｜2019｜essay_question


### record_id

J29-00006

### question

大学生转锦鲤来求考试、考研、求职等获得好运气，你怎么看。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第41行｜四、论述题20分｜原题号2

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00007｜江南大学｜2019｜essay_question


### record_id

J29-00007

### question

高校师德师风建设之我见

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第44行｜五、 作文

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00008｜江南大学｜2019｜structured_interview


### record_id

J29-00008

### question

网络思想政治工作的有效途径是什么?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第45行｜面试｜原题号1

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00009｜江南大学｜2019｜structured_interview


### record_id

J29-00009

### question

请谈谈自身做辅导员的优势和一个缺点。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第45行｜面试｜原题号2

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00010｜江南大学｜2019｜structured_interview


### record_id

J29-00010

### question

有人说辅导员工作需要激情和创新，有人说在这种环境里会甘于现状，你怎么看?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2019

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第45行｜面试｜原题号3

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00011｜江南大学｜2018｜essay_question


### record_id

J29-00011

### question

高等学校教师师德方面要做到四个相统一的具体内容是什么?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第51行｜二、论述题｜原题号1

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00012｜江南大学｜2018｜essay_question


### record_id

J29-00012

### question

请阐述在十九大报告中指出的中国共产党在新时代的使命是什么?红船精神的内涵是什么?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第51行｜二、论述题｜原题号2

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00013｜江南大学｜2018｜essay_question


### record_id

J29-00013

### question

如何理解目前青年中“佛系”心态?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第51行｜二、论述题｜原题号3

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00014｜江南大学｜2018｜structured_interview


### record_id

J29-00014

### question

如何解决贫困学生、困难少数民族和家庭变故等特殊学生的困难?

### material

单独面试：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第60行｜第二轮｜原题号1

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00015｜江南大学｜2018｜structured_interview


### record_id

J29-00015

### question

根据十九大精神总结出5条具有逻辑性的学风建设提纲。

### material

单独面试：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第60行｜第二轮｜原题号2

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00016｜江南大学｜2018｜structured_interview


### record_id

J29-00016

### question

如何开展一次不忘初心牢记使命的教育活动。

### material

单独面试：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第60行｜第二轮｜原题号3

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00017｜江南大学｜2018｜exam_outline


### record_id

J29-00017

### question

一、不定项选择(20 题)

### material

十八届六中全会通过了什么文件?江南大学的校训是?孟子认为的君子三乐是?趋避心理冲突的考察、若干法律相关题、公务员的推理题

### sub_questions



### answer

不生成推断答案；该记录仅保留考试题型、分值或范围概述。

### answer_framework

仅用于命题结构和复习范围分析，不作为完整真题作答。

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第64行｜一、不定项选择(20 题)

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

原文只提供题型、分值、范围或不完整回忆，不伪装为完整真题。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00018｜江南大学｜2018｜short_answer


### record_id

J29-00018

### question

总书记提出的高等教育的四个服务

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第66行｜二、问答题(4题)｜原题号1

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00019｜江南大学｜2018｜short_answer


### record_id

J29-00019

### question

两学一做、四讲四有的内容

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第66行｜二、问答题(4题)｜原题号2

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00020｜江南大学｜2018｜short_answer


### record_id

J29-00020

### question

碎片化阅读的利与弊

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第66行｜二、问答题(4题)｜原题号3

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00021｜江南大学｜2018｜short_answer


### record_id

J29-00021

### question

习近平新疆考察时说“国无常强，国无强弱，奉法者强则国强，奉法者弱则国弱”谈谈你的理解?习近平总书记引用这句话的目的是什么?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第66行｜二、问答题(4题)｜原题号4

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00022｜江南大学｜2018｜material_analysis


### record_id

J29-00022

### question

(1)为什么坚持依法治国和以德治国“两手抓，两手都要硬” (2)如何提高公民法律和道德意识?

### material



### sub_questions

(1)为什么坚持依法治国和以德治国“两手抓，两手都要硬”；(2)如何提高公民法律和道德意识?

### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第71行｜三、论述题(题目中给材料)｜原题号1

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00023｜江南大学｜2018｜material_analysis


### record_id

J29-00023

### question

(1)大学生“空心病”的原因 (2)如何预防空心病(材料中的“空心病”指的是一种心理现象)

### material



### sub_questions

(1)大学生“空心病”的原因；(2)如何预防空心病

### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第71行｜三、论述题(题目中给材料)｜原题号2

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00024｜江南大学｜2018｜exam_outline


### record_id

J29-00024

### question

面试总共3道大题，所有人员题目均相同，提前5分钟看题，准备好后进入教室开始答题，限时7分钟。

### material



### sub_questions



### answer

不生成推断答案；该记录仅保留考试题型、分值或范围概述。

### answer_framework

仅用于命题结构和复习范围分析，不作为完整真题作答。

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第78行｜面试总共3道大题，所有人员题目均相同，提前5分钟看题，准备好后进入教室开始答题，限时7分钟。

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

原文只提供题型、分值、范围或不完整回忆，不伪装为完整真题。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00025｜江南大学｜2018｜structured_interview


### record_id

J29-00025

### question

你为什么应聘江南大学辅导员?你有什么核心竞争力?请举例说明。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第79行｜一、

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00026｜江南大学｜2018｜structured_interview


### record_id

J29-00026

### question

十八届六中全会通过的文件名称是什么?什么是三会一课制度?你是如何参加三会一课的，举例说明?作为一名即将从事辅导员工作的你，如何开展三会一课?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第80行｜二、

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00027｜江南大学｜2018｜essay_question


### record_id

J29-00027

### question

三、习近平总书记说教育工作者要因事而化、因时而进、因势而新，你是如何理解的?请从学生参加活动和辅导员组织活动两个方面进行论述。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江南大学

### school_normalized

江南大学

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第81行｜三、习近平总书记说教育工作者要因事而化、因时而进、因势而新，你是如何理解的?请从学生参加活动和辅导员组织活动两个方面进行论述。

### source_page

2

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00028｜泰州学院｜2018｜exam_outline


### record_id

J29-00028

### question

十大育人体系有哪些?

### material

(只有部分题目，其他记不清了) 简答题：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

泰州学院

### school_normalized

泰州学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第83行｜笔试｜原题号1

### source_page

3

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00029｜泰州学院｜2018｜exam_outline


### record_id

J29-00029

### question

学生享有哪些权利?

### material

(只有部分题目，其他记不清了) 简答题：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

泰州学院

### school_normalized

泰州学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第83行｜笔试｜原题号2

### source_page

3

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00030｜泰州学院｜2018｜structured_interview


### record_id

J29-00030

### question

你要组织班级去几公里外一个小学进行环保宣传，请问你如何组织?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

泰州学院

### school_normalized

泰州学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第87行｜面试｜原题号1

### source_page

3

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00031｜泰州学院｜2018｜case_analysis


### record_id

J29-00031

### question

一个女生借了校园贷，债务缠身，躲在宿舍吃泡面不肯出门，你怎么办?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

泰州学院

### school_normalized

泰州学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第87行｜面试｜原题号2

### source_page

3

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00032｜中国矿业大学｜2018｜short_answer


### record_id

J29-00032

### question

中国特色社会主义新时代总任务

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

中国矿业大学

### school_normalized

中国矿业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第93行｜三、 简答｜原题号5

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00033｜中国矿业大学｜2018｜case_analysis


### record_id

J29-00033

### question

一个毕业班同学失联，怀疑传销，辅导员怎么办?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

中国矿业大学

### school_normalized

中国矿业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第96行｜四、 案例分析｜原题号1

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00034｜中国矿业大学｜2018｜case_analysis


### record_id

J29-00034

### question

一个同学经常说想自杀，经诊断是抑郁症，学校让休学，他执意留在学校，家长说无法陪读，你是辅导员怎么办?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

中国矿业大学

### school_normalized

中国矿业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第96行｜四、 案例分析｜原题号2

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00035｜中国矿业大学｜2018｜essay_question


### record_id

J29-00035

### question

结合辅导员工作，谈谈如何提高高校思想政治工作质量从而推进全员全过程全方位发展。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

中国矿业大学

### school_normalized

中国矿业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第99行｜五、 论述

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00036｜无锡职业技术学院｜2018｜fill_blank


### record_id

J29-00036

### question

到 基本实现现代化，到本世纪中叶，建成 的现代化强国

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第101行｜一、填空｜原题号1

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00037｜无锡职业技术学院｜2018｜fill_blank


### record_id

J29-00037

### question

开展高校思政教育应遵循的三个规律

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第101行｜一、填空｜原题号2

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00038｜无锡职业技术学院｜2018｜fill_blank


### record_id

J29-00038

### question

品德的四个组成部分

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第101行｜一、填空｜原题号3

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00039｜无锡职业技术学院｜2018｜fill_blank


### record_id

J29-00039

### question

中国特色社会主义的特征 和优势 ，党是

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第101行｜一、填空｜原题号5

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00040｜无锡职业技术学院｜2018｜fill_blank


### record_id

J29-00040

### question

高校思想政治教育内容：核心，重点，基础，目标

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第101行｜一、填空｜原题号6

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00041｜无锡职业技术学院｜2018｜fill_blank


### record_id

J29-00041

### question

人大开幕闭幕时间

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第101行｜一、填空｜原题号8

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00042｜无锡职业技术学院｜2018｜short_answer


### record_id

J29-00042

### question

开展高校思想政治教育载体有哪些?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第108行｜二、简答题｜原题号1

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00043｜无锡职业技术学院｜2018｜short_answer


### record_id

J29-00043

### question

如果你是毕业班的辅导员，你如何开展学生就业工作?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第108行｜二、简答题｜原题号2

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00044｜无锡职业技术学院｜2018｜short_answer


### record_id

J29-00044

### question

简述思想品德的形成和发展规律

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第111行｜三、论述题｜原题号1

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00045｜无锡职业技术学院｜2018｜essay_question


### record_id

J29-00045

### question

假如你是辅导员，你该如何掌握学生思想动态

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第111行｜三、论述题｜原题号2

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00046｜无锡职业技术学院｜2018｜blog_writing


### record_id

J29-00046

### question

四、博文二选一(我选的根据《厉害了我的国》唤起学生的爱国主义情怀创作博文)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

标题—立意—学生视角—案例/论据—行动倡议

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

blog_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第114行｜四、博文二选一(我选的根据《厉害了我的国》唤起学生的爱国主义情怀创作博文)

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00047｜无锡职业技术学院｜2018｜structured_interview


### record_id

J29-00047

### question

谈谈网络和新媒体对高校思想政治教育的影响

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第115行｜面试｜原题号1

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00048｜无锡职业技术学院｜2018｜theme_class_meeting


### record_id

J29-00048

### question

某辅导员和班长组织了一堂关于考试违纪的主题班会，内容主要围绕考试违纪的行为和后果展开，再由各个小组派一个代表起来谈谈感想，最后全班朗读考试纪律 (1)你认为这个班会的效果怎样?有什么弊端?(2)如果是你会怎样组织这堂班会? (3)假如你班里有人考试违纪，你打算如何处理?

### material



### sub_questions

(1)你认为这个班会的效果怎样?有什么弊端?；(2)如果是你会怎样组织这堂班会?；(3)假如你班里有人考试违纪，你打算如何处理?

### answer

原资料未提供可核验标准答案

### answer_framework

目标—对象—流程—互动—评估

### school_original

无锡职业技术学院

### school_normalized

无锡职业技术学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

theme_class_meeting

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第115行｜面试｜原题号2

### source_page

4

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00049｜苏州大学｜2018｜short_answer


### record_id

J29-00049

### question

习近平新时代中国特色社会主义思想内容

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第123行｜二、简答题｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00050｜苏州大学｜2018｜short_answer


### record_id

J29-00050

### question

辅导员的工作职责

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第123行｜二、简答题｜原题号2

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00051｜苏州大学｜2018｜material_analysis


### record_id

J29-00051

### question

新生入学教育方案

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第125行｜三、材料题｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00052｜苏州大学｜2018｜material_analysis


### record_id

J29-00052

### question

关于失恋逃课措施和辅导员工作启示

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第125行｜三、材料题｜原题号2

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00053｜苏州大学｜2017｜objective_question


### record_id

J29-00053

### question

阅读理解2、数量关系3、数学计算4、图形推理5、推理判断6、资料分析可以参考公务员考试题型和题目

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第128行｜一、行测部分(50’)｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00054｜苏州大学｜2017｜short_answer


### record_id

J29-00054

### question

社会主义核心价值观

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第130行｜二、简答题(10’)｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00055｜苏州大学｜2017｜material_analysis


### record_id

J29-00055

### question

四、结合材料，写一个2017级新生入学教育计划(20’)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第133行｜四、结合材料，写一个2017级新生入学教育计划(20’)

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00056｜苏州大学｜2016｜short_answer


### record_id

J29-00056

### question

四个全面的基本内涵

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第138行｜一、简答(10’)｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00057｜苏州大学｜2016｜short_answer


### record_id

J29-00057

### question

辅导员的职业功能

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第138行｜一、简答(10’)｜原题号2

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00058｜苏州大学｜2016｜theme_class_meeting


### record_id

J29-00058

### question

设计“规范和引导大学生网络行为的主题班会方案

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

目标—对象—流程—互动—评估

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

theme_class_meeting

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第141行｜二、论述(40’)｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00059｜苏州大学｜2016｜case_analysis


### record_id

J29-00059

### question

案例：小明考上理想大学但不是理想专业，大一郁闷一整年考试挂科两门，结合案例分析入学后如何开展专业思想教育和心理辅导。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第141行｜二、论述(40’)｜原题号2

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00060｜苏州大学｜2016｜structured_interview


### record_id

J29-00060

### question

竞争辅导员的优势和对辅导员素质的定位

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第144行｜面试｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00061｜苏州大学｜2016｜structured_interview


### record_id

J29-00061

### question

辅导员工作岗位要做好哪几个方面

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第144行｜面试｜原题号2

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00062｜苏州大学｜2016｜english_response


### record_id

J29-00062

### question

英语对话(我当时问的是为什么你这么喜欢做学生工作)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—理由—例证—总结，注意英文表达

### school_original

苏州大学

### school_normalized

苏州大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

english_response

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第144行｜面试｜原题号3

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00063｜江苏理工学院｜2018｜structured_interview


### record_id

J29-00063

### question

习总书记说的不驰于空想，不骛于虚声，你怎样理解这句话?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江苏理工学院

### school_normalized

江苏理工学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第149行｜未标注题型｜原题号1

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00064｜江苏理工学院｜2018｜activity_plan


### record_id

J29-00064

### question

你是辅导员，请你组织一场文艺晚会，说说你会怎么做?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

目标—对象—时间地点—流程—风险预案—评估

### school_original

江苏理工学院

### school_normalized

江苏理工学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

activity_plan

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第149行｜未标注题型｜原题号2

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00065｜江苏理工学院｜2018｜case_analysis


### record_id

J29-00065

### question

小红总是深夜煲电话粥，影响同学休息同学来找你，想要调换宿舍你怎么办?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏理工学院

### school_normalized

江苏理工学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第149行｜未标注题型｜原题号3

### source_page

5

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00066｜南京科技职业学院｜2018｜blog_writing


### record_id

J29-00066

### question

以“投笔从戎 为国从军”为主题，800字，40分钟内完成

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

标题—立意—学生视角—案例/论据—行动倡议

### school_original

南京科技职业学院

### school_normalized

南京科技职业学院

### province

江苏省

### year

2018

### exam_stage

written

### question_type

blog_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第154行｜一、博文写作

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00067｜南京科技职业学院｜2018｜essay_question


### record_id

J29-00067

### question

学校准备加强教师的团队合作能力和身体素质，如果你是负责人会组织怎样的活动?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京科技职业学院

### school_normalized

南京科技职业学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第156行｜二、结构化面试，共15分钟(包括审题和论述，提供稿纸)｜原题号1

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00068｜南京科技职业学院｜2018｜essay_question


### record_id

J29-00068

### question

学校安排你和小李一起完成一项任务，但小李不愿合作，效率很低，你该如何处理?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京科技职业学院

### school_normalized

南京科技职业学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第156行｜二、结构化面试，共15分钟(包括审题和论述，提供稿纸)｜原题号2

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00069｜南京科技职业学院｜2018｜essay_question


### record_id

J29-00069

### question

如何理解正确的做事、做正确的事之间的关系?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京科技职业学院

### school_normalized

南京科技职业学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第156行｜二、结构化面试，共15分钟(包括审题和论述，提供稿纸)｜原题号3

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00070｜南京科技职业学院｜2018｜speech


### record_id

J29-00070

### question

岗位能力测试 分为案例分析和主题演讲，各5分钟，抽签答题，提供稿纸在候考室备考 案例其中一道是： 如何处理军训结束前一晚有女生因不舍教官，在宿舍楼下喊楼，事后朋友圈疯转这件事。 主题演讲其中一道是： “守好一段渠，种好责任田”

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

主题—对象—情感—事例—号召

### school_original

南京科技职业学院

### school_normalized

南京科技职业学院

### province

江苏省

### year

2018

### exam_stage

interview

### question_type

speech

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第160行｜三、

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00071｜南京农业大学｜2018｜objective_question


### record_id

J29-00071

### question

二、选择题(15)行测(常识判断数量关系逻辑推理言语理解)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京农业大学

### school_normalized

南京农业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第169行｜二、选择题(15)行测(常识判断数量关系逻辑推理言语理解)

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00072｜南京农业大学｜2018｜official_writing


### record_id

J29-00072

### question

学校将在体育中心举行迎新晚会，请问以学生处工作人员名义，起草一份文件请学校体育部协助做好会场电力设备，安全管理等相关工作。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

文种判断—对象目的—格式—正文结构—落款

### school_original

南京农业大学

### school_normalized

南京农业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

official_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第170行｜三、小公文写作(25)｜原题号1

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00073｜南京农业大学｜2018｜official_writing


### record_id

J29-00073

### question

我院学生小明将参加省里优秀学生评选。请编写一条微信朋友圈。为该学生拉票。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

文种判断—对象目的—格式—正文结构—落款

### school_original

南京农业大学

### school_normalized

南京农业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

official_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第170行｜三、小公文写作(25)｜原题号2

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00074｜南京农业大学｜2018｜material_analysis


### record_id

J29-00074

### question

四段材料分别描述学生学习积极性不高，大学生沦为手机控，低头族。某高校开展开除成绩不合格学生。某高校试点无手机课堂。 请从材料背景，问题，措施、启示四个方面进行论述。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

南京农业大学

### school_normalized

南京农业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第173行｜四、材料分析题(20)

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00075｜南京农业大学｜2018｜official_writing


### record_id

J29-00075

### question

我校拟定5 月 20 号为辅导员日。届时学校将举办相关活动。请为出席活动的领导写一篇讲话稿。一千字左右。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

文种判断—对象目的—格式—正文结构—落款

### school_original

南京农业大学

### school_normalized

南京农业大学

### province

江苏省

### year

2018

### exam_stage

written

### question_type

official_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第176行｜五、公文写作

### source_page

6

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00076｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00076

### question

十四中全会决定提出，社会主义法治的根本要求是(B) A、全面深化改革 B、坚持党的领导 C、完善法治建设 D、推进依法行政

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00077｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00077

### question

经国务院授权，国家发改委等三部委于2015 年3 月28 日联合发布了《推动共建丝绸之路经济带和21 世纪海上丝绸之路的愿景与行动》。关于“一带一路”的愿景与行动，下列说法正确的是(C) A、相关的国家限于覆盖丝绸之路的范围 B、重点方向之一是从中国沿海到南美洲 C、建设的优先领域是基础设施互联互通 D、建设的重点内容是加强金融监管合作

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00078｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00078

### question

中国筹建亚投行的倡议得到许多国家的积极回应，截止2015 年4 月15 日，亚投行意向创始成员国最终确定 57 个。这表明：(D) A、中国奉行的是以平等互利为宗旨的外交政策 B、中国目前已经成为世界上最大的对外投资国 C、中国的银行体系完成能够防范国际金融风险 D、中国合作共赢的理念得到国际社会的广泛认同

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号3

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00079｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00079

### question

加快转变政府职能要健全宏观调控体系。下列政策属于宏观调控体系的主要手段的是(A) A、财政政策和货币政策 B、货币政策和产业政策 C、产业政策和价格政策 D、价格政策和财政政策

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号4

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00080｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00080

### question

“硬水”中含有较多的可溶性钙镁化合物，容易产生白色沉淀的水垢，下列关于“硬水”对日常生活影响的说法，正确的是(C) A、延长容器中热水的保温时间B、增加肥皂和清洁剂的洗涤效率 C、增加水在加热中的能源消耗 D、减少水中含有的其他化合物

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号5

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00081｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00081

### question

排序题: 13542

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号6

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00082｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00082

### question

小李设计了一款舞蹈机器人

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00083｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00083

### question

某厂家与小李洽谈批量生产“舞蹈达人”

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00084｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00084

### question

小李带着舞蹈机器人参加表演赛

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号3

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00085｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00085

### question

小李获得“中国机器人大赛一等奖”

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号4

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00086｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00086

### question

机器人的表演极为成功，赢得“舞蹈达人”称号

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号5

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00087｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00087

### question

蘑菇：雨伞下列词或者词组关系与上述关系最为相似的是(B) A、石头：印章B、鲸鱼：潜艇 C、龙虾：机器 D、芹菜：蔬菜

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号7

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00088｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00088

### question

农户：养殖下列词或者词组关系与上述关系最为相似的是A A、民工：建筑B、教师：仪表 C、商人：商城 D、编辑：文字

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号8

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00089｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00089

### question

体温计水银柱上升：体温上升下列词或者词组关系与上述关系最为相似的是B A、减少尾气排放：降低污染程度 B、电灯亮：有电 C、救人：被表彰 D、彼此相爱：结婚

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号9

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00090｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00090

### question

铁：铜：金属下列词或者词组关系与上述关系最为相似的是B A、枝：桠：树木B、红：蓝：颜色 C、海：螺：海螺 D、高：低：山洼

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号10

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00091｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00091

### question

包：布包：帆布包下列词或者词组关系与上述关系最为相似的是C A、水：蒸馏水：蒸发了的蒸馏水 B、洲：亚洲：东南亚国家 C、字：汉字：“汉”这个字 D、丈：一丈：魔高一丈

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号11

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00092｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00092

### question

拼养指的是几个家庭组成小组，每家父母周末轮流照看小组中三岁以上的孩子。假设这个定义是正确的，不容置疑的，则下列属于拼养的是(D) A、小王在某旅行社工作，经常周末带队旅游。为了工作，他常把孩子托付给孩子姑妈照看。 B、小名、小敏和小龙是同同一个幼儿园的好朋友，每到周末三个孩子都由父母带着去郊外玩耍。 C、张某、林某，王某的孩子分别为四岁、五岁、六岁，三家商议共同找一个保姆到周末就把孩子们放在保姆家由保姆照看。 D、潘某和赵某的孩子都上幼儿园大班，俩家人商议，每逢单周赵家照看潘某的孩子，逢双周潘家照看赵某的孩子，这样安排可以释放更多的时间，孩子有玩伴不孤单。

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号12

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00093｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00093

### question

漂二代：漂二代：指在故乡出生后又离开故乡，随父母一起在外漂泊的人。假设这个定义是正确的、不容置疑的、则下列属于漂二代的是(C) A、张某在国外打拼了10 年，找到了稳定的工作，为了尽孝，把国内的年老的父母接到身边照顾 B、王某离开偏僻的小山村，在某大城市当快递员，两年后遇到心上人，闪婚后生了一个胖小子 C、程某小学刚毕业，老家拆迁，他父母到北京打工，他则在北京五环外的一所民工子弟学校读书 D、小江的妈妈调到南方的某高校任教，小江自己则考上了北方的一所大学

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号13

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00094｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00094

### question

试考族：指抱着试一试的心态参加各种考试的人。假设这个定义是正确的、不容置疑的、则下列属于试考族的是(A) A、小张是应届本科生，他今年参加了几个省的“公考”，目的是为了“练兵” B、小李是应届毕业生，他为参加国考准备了一年时间，势在必得 C、王女士的女儿喜欢参加各类艺术竞赛，王女士本人经常陪同女儿参赛 D、老赵已经退休了，为了弥补年轻时因为家穷没有上大学的遗憾，自学了高中的全部课程，准备参加高考

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号14

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00095｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00095

### question

慕课：指大规模在线开放式网络课程，可以实现学习进度的管理，在线交流互动。假设上述定义是正确的，不容置疑的，则下列属于慕课的是：(D) A、某网络公司跟小陈合作，记录了他的旅游学课程的全部内容，准备制作后在网上在线播放 B、某高校开设了一些网络在线课程，只有已经选修到该课程的校内学生才能参与学习，并有机会获得学分 C、小王在某网站发现了一款象棋学习软件，完成了付费后下载到自己的电脑中，小王通过这款软件可以与网友对弈 D、小李发现了国外某些著名大学的联合网络课程中有自己喜欢的历史课程，注册成功后，小李成为了该课程的学员，小李每次提交作业都有老师批改

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号15

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00096｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00096

### question

随着卫星技术的不断推广，太空垃圾越来越多，科学家们也就发出警告：“如果卫星大国不重视预防和消除太空垃圾，那么总有一天将无法使用太空。”以下项的含义与科学家们的警告最为接近的是: (C) A、总有那么一天，太空不能被随意使用 B、只要重视太空垃圾的预防和消除，太空就可以一直随意使用下去 C、各卫星大国只有重视预防和消除太空垃圾，才能预防太空无法随意使用的后果 D、太空如果有一天不能被随意使用，那是因为各国卫星大国没有重视太空

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号16

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00097｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00097

### question

一位心理学家对初中二年级的两组学生做了调查，甲组的学生每天打电脑游戏的时间平均约一小时，乙组学生从不打电脑游戏，结果发现甲组学生中执拗性格者所占比例要远远高于乙组学生，于是他认为打电脑游戏容易使孩子执拗任性，以下哪项如果为真，对这位心理学家的论点构成挑战。(D) A、甲组中有的学生并不执拗任性 B、乙组中有的学生比甲组中有的学生执拗任性 C、乙组中很多学生非常听话 D、甲组中很多学生的执拗任性是他们家长溺爱造成的

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号17

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00098｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00098

### question

如果以“如果产品的质量和价格都没有提高，那么其销售量肯定加大了”为前提，那么应该追加以下哪项，可以推出产品的质量事实上提高了“之结论(D) A、产品的销量加大了 B、产品的销量没有加大 C、产品的价格没有提高 D、产品价格没有提高，并且销量也没有加大。

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号18

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00099｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00099

### question

不入虎穴，不得虎子，据此推不出的是(D) A.只有入虎穴，才得虎子 B.如果不入虎穴，那么不得虎子 C.或着入虎穴，或者不得虎子 D.并非入虎穴而不得虎子。

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号19

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00100｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00100

### question

如果 B 股票涨或者 C 股票跌，那么 A 股票涨；如果 B 股票跌，那么 D 股票涨；如果 C 股票涨，那么 E 股票跌； A 股票大跌,(A)。 A、D股票涨，并且 E 股票跌 B、D股票跌，并且 E 股票涨 C、D股和 E 股都跌 D、D股和 E 股票都涨

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号20

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00101｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00101

### question

2015年5月9日，俄罗斯举行世界反法西斯战争胜利七十周年纪念活动，并邀请我国派出仪仗队参与该活动。就入选2015年红场阅兵式仪仗队的成员问题，张、李、王作了如下断定： 张：如果甲入选，那么丙不入选李：如果丁入选，那么乙不入选王：丙和丁都入选，如果三人的断定都是真的，那么可以推出(D) A、甲不入选，乙入选 B、甲入选，乙不入选 C、甲和乙都入选 D、甲和乙都不入选

### material

单选(回忆不全)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第181行｜一、｜原题号21

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00102｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00102

### question

李克强总理在《政府工作报告》中指出，要推动大众创业、万众创新。下列说法正确的有(ABCD) A、这是要打造经济发展的新引擎 B、这可以消除经济下行的压力 C、这可以扩大就业和增加居民收入 D、这有利于促进社会公平正义

### material

多选(共 5 题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第253行｜二、｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00103｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00103

### question

江苏省人大于2015 年2 月通过的《江苏省大气污染防治条列》，设区的市、县 (市)人民政府“采取控制机动车保有量的措施，应当公开征求的意见，经同级人民代表大会常务委员会审议，并在实施三十日以前向社会公告”。对此，说法正确的有(ABCD) A、这规定了采取“限牌”措施必须遵循的程序 B、这是把“限牌”的行政行为纳入法治的轨道 C、这是要让政府“限牌”的权利在阳光下运行 D、这有利于使“限牌”得到公众的理解和支持

### material

多选(共 5 题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第253行｜二、｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00104｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00104

### question

在法治社会构建中，社会主体实现自我约束、自我管理的社会规范有(ABCD) A、团体章程 B、市民公约 C、乡规民约 D、行业规章

### material

多选(共 5 题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第253行｜二、｜原题号3

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00105｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00105

### question

苏某于 Z 公司发布上年度报告之后购买其股票并发生亏损，Z公司因财务信息虚假及重大事项隐瞒被证监会处罚。苏某向人民法院起诉，要求 Z 公司赔偿损失。对此，下列说法正确的有：(AC) A、证监会对 Z 公司的处罚属于行政处罚 B、Z 公司不应当在承担民事责任 C、苏某有权要求 Z 公司承担赔偿责任 D、信息持续公开是所有股份有限公司的基本义务。

### material

多选(共 5 题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第253行｜二、｜原题号4

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00106｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00106

### question

价值规律的表现形式是价格围绕价值波动，下列价格变动符合价值规律的有：(ABCD) A、某农产品的市场价格因气候原因减产，而从每千克 3 元涨到

### material

多选(共 5 题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第253行｜二、｜原题号5

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00107｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00107

### question

5元 B、家用电子产品的价格由于新的型号和品种的推出而持续出现下降 C、一场高雅艺术演出的门票价格因一票难求在原价的基础上调高了20% D、商场采取奖励、打折、馈赠等促销手段使商品的实际售价有所下降。

### material

多选(共 5 题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第253行｜二、｜原题号3

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00108｜江苏省属事业单位辅导员岗｜2015上半年｜exam_outline


### record_id

J29-00108

### question

3分) 根据图表计算五道题目，比较简单。 比如那个时期的天然气产量占当时能源总产量的比例最高等等

### material

综合分析题(共 5 题,每题

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第271行｜三、｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00109｜江苏省属事业单位辅导员岗｜2015上半年｜objective_question


### record_id

J29-00109

### question

非常简单，不用备考也可以考对大半要想正确率再高点，就好好看咱们资料就完全可以主要有大学生心理健康、教育相关法律法规(就是几岁是完全行为能力人、教师的权利、义务等那些比较基础的)、学生工作的具体情况的处理等。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第275行｜一、选择(15 道题，都是单选)

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00110｜江苏省属事业单位辅导员岗｜2015上半年｜material_analysis


### record_id

J29-00110

### question

李克强倡导“万众创新”，“大众创业”给一段文字材料(与以下文字材料类似，但不是原材料，是我找给大家参考的) 大众创业、万众创新被视作中国新常态下经济发展“双引擎”之一。李克强对中外企业家说，“创新不单是技术创新，更包括体制机制创新、管理创新、模式创新，中国 30 多年来改革开放本身就是规模宏大的创新行动，今后创新发展的巨大潜能仍然蕴藏在制度变革之中。”创新不单是技术创新，更包括体制机制创新、管理创新、模式创新，中国 30 多年来改革开放本身就是规模宏大的创新行动，今后创新发展的巨大潜能仍然蕴藏在制度变革之中。草根创新创业，将成为中国经济未来增长的不熄引擎。中国有13亿多人口，9亿劳动力，7000万企业和个体工商户，蕴藏着无穷的创造力。鼓励支持利用闲置厂房等多种场所、孵化基地等多种平台、风险投资等多种融资渠道开展创业创新，形成小企业“铺天盖地”，大型企业“顶天立地”的格局。万千“草根”是创新创业的主体，大学生、研究生创业是“草根创新”的重要力量，不鼓励大学生、研究生走摆地摊、开咖啡店式创业之路，引导他们走“需求拉动、创新驱动”之路，开展科技成果研发和转化。 结合这段材料，如果你是辅导员，谈谈你的看法

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第277行｜二、材料分析题(2道题)｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00111｜江苏省属事业单位辅导员岗｜2015上半年｜material_analysis


### record_id

J29-00111

### question

一段文字，最后提出的问题是，社会主义核心价值观与辅导员工作的结合，谈谈你作为辅导员的看法

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015上半年

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第277行｜二、材料分析题(2道题)｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00112｜江苏省属事业单位辅导员岗｜2015下半年｜objective_question


### record_id

J29-00112

### question

学生最近听说了一些不好的时事，辅导员邀请专家过来座谈，辅导员在这件事情中扮演的角色( ) A 组织者 B 管理者 C 指导者 D 实施者

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第286行｜一、 单选 (10 题)｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00113｜江苏省属事业单位辅导员岗｜2015下半年｜objective_question


### record_id

J29-00113

### question

学生作弊，选择了自己安慰自己说别人也会作弊的，反映了这位学生的什么心理? A 折射心理C 转移心理

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第286行｜一、 单选 (10 题)｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00114｜江苏省属事业单位辅导员岗｜2015下半年｜speech


### record_id

J29-00114

### question

“主题演讲”、“迎新活动”等都是采用了哪种教育方法?( ) A 活动教育法 B 情景教育法 C 课堂教育法D 课外教育法

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

主题—对象—情感—事例—号召

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

interview

### question_type

speech

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第286行｜一、 单选 (10 题)｜原题号3

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00115｜江苏省属事业单位辅导员岗｜2015下半年｜objective_question


### record_id

J29-00115

### question

辅导员是大学生思想政治教育工作的组织者、指导者和实施者，以下哪项不是辅导员的 职责?( ) A 学业教育指导 B 就业指导 C 职业生涯规划

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第286行｜一、 单选 (10 题)｜原题号4

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00116｜江苏省属事业单位辅导员岗｜2015下半年｜situational_simulation


### record_id

J29-00116

### question

以下属于职业规划教育的是 ( ) A 大学生新生长跑运动会 B 提升面试技巧 C抓学风教育 D 情景模拟

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

建立关系—倾听澄清—回应方案—边界与跟进

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

interview

### question_type

situational_simulation

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第295行｜二、 多选｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00117｜江苏省属事业单位辅导员岗｜2015下半年｜objective_question


### record_id

J29-00117

### question

以下属于大学生健康心理素质的是 ( ) A 思想开朗活泼 B 遇事不抱怨

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第295行｜二、 多选｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00118｜江苏省属事业单位辅导员岗｜2015下半年｜objective_question


### record_id

J29-00118

### question

学生家人去世，意外伤害，还有失恋，丢东西，这些属于哪种情景性 ( ) A 成长性危机 B 境遇性危机 C 现实性危机

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第295行｜二、 多选｜原题号3

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00119｜江苏省属事业单位辅导员岗｜2015下半年｜case_analysis


### record_id

J29-00119

### question

大学生资助体系有哪些 ( ) A 国家助学金 B 企业资助的助学金 C 奖学金 D 勤工俭学

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第295行｜二、 多选｜原题号4

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00120｜江苏省属事业单位辅导员岗｜2015下半年｜official_writing


### record_id

J29-00120

### question

两学生打架发展成群体性事件，应急机制的做法有哪些?( ) A 第一时间通知家长 B及时赶到现场控制局面 C依照法律法规和校规处置

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

文种判断—对象目的—格式—正文结构—落款

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

official_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第295行｜二、 多选｜原题号5

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00121｜江苏省属事业单位辅导员岗｜2015下半年｜objective_question


### record_id

J29-00121

### question

以下属于学风建设的有哪些?( )

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第295行｜二、 多选｜原题号6

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00122｜江苏省属事业单位辅导员岗｜2015下半年｜material_analysis


### record_id

J29-00122

### question

关于大学生创业、做小买卖开公司，对大学生的利弊。

### material

第一大题：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第307行｜二、材料分析题 (2题)｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00123｜江苏省属事业单位辅导员岗｜2015下半年｜material_analysis


### record_id

J29-00123

### question

谈谈作为辅导员怎么引导学生正确处理学业和创业的关系? 第二大题：

### material

第一大题：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第307行｜二、材料分析题 (2题)｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00124｜江苏省属事业单位辅导员岗｜2015下半年｜case_analysis


### record_id

J29-00124

### question

钟明之前学习成绩不错，后来进入到大二之后沉迷网络，学业挂科，不爱与人交往，学 校也采取了措施但是效果不好。作为钟明的辅导员该如何引导他破除网瘾?

### material

第一大题：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第307行｜二、材料分析题 (2题)｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00125｜江苏省属事业单位辅导员岗｜2015下半年｜activity_plan


### record_id

J29-00125

### question

5.25 心理宣传月，以大学生网络心理为主题，写一篇活动策划 2016下半年(回忆版)

### material

第一大题：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

目标—对象—时间地点—流程—风险预案—评估

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

activity_plan

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第307行｜二、材料分析题 (2题)｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00126｜江苏省属事业单位辅导员岗｜2015下半年｜material_analysis


### record_id

J29-00126

### question

开展讲座，开始学生很多，但是后来渐渐很少，问辅导员怎么看开展此类讲座。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第320行｜三、材料分析｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00127｜江苏省属事业单位辅导员岗｜2015下半年｜material_analysis


### record_id

J29-00127

### question

贫困助学金评定公示期间，有人匿名网上举报某同学作假，平日铺张浪费等，引起同学跟贴。问辅导员怎么应对。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第320行｜三、材料分析｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00128｜江苏省属事业单位辅导员岗｜2015下半年｜material_analysis


### record_id

J29-00128

### question

作文是提供一篇材料，表达形式类似公务员里边的申论作文，材料描写了辅导员一天的工作，其中涉及学生学习、就业、创新创业、心理健康、校园活动等等日常工作，还有领导安排的工作，然后以“不忘初心，追求卓越”为主题，自拟题目，写一篇八百字左右的文章。 2017上半年(回忆版)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第323行｜四、 作文

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00129｜江苏省属事业单位辅导员岗｜2015下半年｜objective_question


### record_id

J29-00129

### question

单选10 个,一个0.5 分。 基本是辅导员基本工作相关的常识，第一道与时政联系，是12月习大大参与的一个什么相关会议。还有一道问什么是大学生思想政治教育的主渠道，这个我在16 号文件上看过，很简单，答案是理论课，算是比较正规的题了，其他都很灵活，也很简单，没法具体准备，就用你的常识去理解。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第329行｜一、

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00130｜江苏省属事业单位辅导员岗｜2015下半年｜case_analysis


### record_id

J29-00130

### question

材料1 是大概讲述辅导员的角色定位，职责，应该如何创新做好榜样 材料2 是一个新上任的辅导员第一次带新生，做了很多准备工作，军训期间去学生宿舍，发现各种状况，有沉迷游戏的，有宿舍脏乱差的，没有学习规划的…… 材料3 刘辅导员带的一个女学生家庭条件挺好，但是不受控制偷了别人手机，对方威胁要5倍价钱否则告发，这个女生哭着找辅导员不知怎么办，辅导员替她保守秘密，安慰情绪，找学工处找到被偷的学生好好教育，带偷东西的女生去看心理老师，后来这个女生情况好转。 材料4 小高是新辅导员，带学生组建了篮球队和别的学校打比赛，对方学生场上犯规，然后辅导员非常生气，没有控制好自己，双方打起来了。 (1)结合材料2，谈谈怎么解决新手辅导员面临的这些问题， 300 字左右 (2)结合材料3 和4，比较刘老师和小高老师的做法， 300 字左右 (3)大作文，以“不负使命，做好高校辅导员”为主题写一篇议论文， 1000 字左右 2017下半年(回忆版)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第333行｜三、材料分析

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00131｜江苏省属事业单位辅导员岗｜2015下半年｜essay_question


### record_id

J29-00131

### question

面对新时代的新矛盾，谈谈思政工作的新挑战

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第347行｜三、论述

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00132｜江苏省属事业单位辅导员岗｜2015下半年｜exam_outline


### record_id

J29-00132

### question

针对学生社会兼职，学校应如何引导和管理？

### material

实务操作

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第351行｜五、｜原题号1

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00133｜江苏省属事业单位辅导员岗｜2015下半年｜exam_outline


### record_id

J29-00133

### question

面对逃课兼职的学生，辅导员应该如何对待？

### material

实务操作

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏省属事业单位

### school_normalized

江苏省属事业单位辅导员岗

### province

江苏省

### year

2015下半年

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第351行｜五、｜原题号2

### source_page

7

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00134｜淮阴师范学院｜2017｜exam_outline


### record_id

J29-00134

### question

一、 选择题 二、判断题

### material

包括时政，辅导员知识，高校思政教育，学校相关知识等。

### sub_questions



### answer

不生成推断答案；该记录仅保留考试题型、分值或范围概述。

### answer_framework

仅用于命题结构和复习范围分析，不作为完整真题作答。

### school_original

淮阴师范学院

### school_normalized

淮阴师范学院

### province

江苏省

### year

2017

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第356行｜一、 选择题 二、判断题

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

原文只提供题型、分值、范围或不完整回忆，不伪装为完整真题。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00135｜淮阴师范学院｜2017｜short_answer


### record_id

J29-00135

### question

辅导员的角色定位和素质能力

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

淮阴师范学院

### school_normalized

淮阴师范学院

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第358行｜三、简答题｜原题号1

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00136｜淮阴师范学院｜2017｜short_answer


### record_id

J29-00136

### question

如何实践高校思想政治教育的途径和方法

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

淮阴师范学院

### school_normalized

淮阴师范学院

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第358行｜三、简答题｜原题号2

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00137｜河海大学｜2017｜exam_outline


### record_id

J29-00137

### question

一、多项选择二、填空

### material

绝大部分是关于学校概况，少量时政和辅导员基础知识；

### sub_questions



### answer

不生成推断答案；该记录仅保留考试题型、分值或范围概述。

### answer_framework

仅用于命题结构和复习范围分析，不作为完整真题作答。

### school_original

江苏河海大学

### school_normalized

河海大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第364行｜一、多项选择二、填空

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

原文只提供题型、分值、范围或不完整回忆，不伪装为完整真题。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00138｜河海大学｜2017｜short_answer


### record_id

J29-00138

### question

学生认为思政教育没有必要，你怎么看？

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏河海大学

### school_normalized

河海大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第366行｜三、问答题｜原题号1

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00139｜河海大学｜2017｜short_answer


### record_id

J29-00139

### question

给某部分发公函一起举办活动

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏河海大学

### school_normalized

河海大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第366行｜三、问答题｜原题号2

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00140｜河海大学｜2017｜short_answer


### record_id

J29-00140

### question

联系辅导员职责与思政教育，谈谈看法。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏河海大学

### school_normalized

河海大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第366行｜三、问答题｜原题号3

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00141｜河海大学｜2017｜case_analysis


### record_id

J29-00141

### question

面试 结构化面试抽签分两组，排到后5 分钟看题备考，5分钟作答。 候考时间很长，我们组题目有3 道， 第一题自我介绍及优势 第二题辅导员应当具备哪些方面知识 第三题学生校园内车祸突发危机处理

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏河海大学

### school_normalized

河海大学

### province

江苏省

### year

2017

### exam_stage

interview

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第369行｜第一轮

### source_page

13

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00142｜江苏大学｜2017｜objective_question


### record_id

J29-00142

### question

学校不需要承担责任的情况

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第381行｜一、选择题15题(每题1分)｜原题号1

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00143｜江苏大学｜2017｜objective_question


### record_id

J29-00143

### question

团员年龄，退团14岁28周岁

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第381行｜一、选择题15题(每题1分)｜原题号2

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00144｜江苏大学｜2017｜objective_question


### record_id

J29-00144

### question

辅导员哪项不是，业务精，政治强

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第381行｜一、选择题15题(每题1分)｜原题号3

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00145｜江苏大学｜2017｜objective_question


### record_id

J29-00145

### question

十八届六中全会议题，全面从严治党

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第381行｜一、选择题15题(每题1分)｜原题号4

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00146｜江苏大学｜2017｜objective_question


### record_id

J29-00146

### question

师说韩愈 师者，所以传道受业解惑也

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第381行｜一、选择题15题(每题1分)｜原题号5

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00147｜江苏大学｜2017｜objective_question


### record_id

J29-00147

### question

有个主张是那个的孟子老子墨子韩非子

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第381行｜一、选择题15题(每题1分)｜原题号6

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00148｜江苏大学｜2017｜case_analysis


### record_id

J29-00148

### question

贫困生买新手机怎么教育

### material

30分

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第385行｜二、 案例题｜原题号1

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00149｜江苏大学｜2017｜case_analysis


### record_id

J29-00149

### question

评奖学金评定方法吐槽在朋友圈

### material

30分

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第385行｜二、 案例题｜原题号2

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00150｜江苏大学｜2017｜case_analysis


### record_id

J29-00150

### question

某同学上课散漫老师很生气

### material

30分

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第385行｜二、 案例题｜原题号3

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00151｜江苏大学｜2017｜exam_outline


### record_id

J29-00151

### question

全国高校思政工作会议中提到“立德树人”的重要意义和实现的有效途径

### material

分析题15分

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第388行｜三、｜原题号1

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00152｜江苏大学｜2017｜exam_outline


### record_id

J29-00152

### question

高校政治思想的合理性

### material

分析题15分

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第388行｜三、｜原题号2

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00153｜江苏大学｜2017｜blog_writing


### record_id

J29-00153

### question

“国际视野和人文情怀”的博文

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

标题—立意—学生视角—案例/论据—行动倡议

### school_original

江苏大学

### school_normalized

江苏大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

blog_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第391行｜四、写作题25分

### source_page

14

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00154｜南京工业大学｜2017｜short_answer


### record_id

J29-00154

### question

专职辅导员的能力和素质要求

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京工业大学

### school_normalized

南京工业大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第404行｜三、简答题(5 分*2)｜原题号1

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00155｜南京工业大学｜2017｜short_answer


### record_id

J29-00155

### question

辅导员怎样开展网络思想政治工作

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京工业大学

### school_normalized

南京工业大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第404行｜三、简答题(5 分*2)｜原题号2

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00156｜南京工业大学｜2017｜case_analysis


### record_id

J29-00156

### question

辅导员如何发挥校园文化的育人功能

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

南京工业大学

### school_normalized

南京工业大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第407行｜四、案例分析(10*2)｜原题号1

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00157｜南京工业大学｜2017｜speech


### record_id

J29-00157

### question

奖学金助学金评定过程中，有学生反映助学金不能只按成绩排名，辅导员召集办会，要求贫困生上台演讲，民主评议。学生小王与王老师理论，说助学金应该按贫困等级不应该只给成绩优秀的贫困生。辅导员告诉他这是大家选出来的结果，辅导员也没办法。问怎么评价辅导员的做法，如果是你怎么办?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

主题—对象—情感—事例—号召

### school_original

南京工业大学

### school_normalized

南京工业大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

speech

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第407行｜四、案例分析(10*2)｜原题号2

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00158｜南京工业大学｜2017｜material_analysis


### record_id

J29-00158

### question

给了一些材料，要求写作如何做好95 后大学生职业生涯规划和就业指导工作。500 字

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

南京工业大学

### school_normalized

南京工业大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第412行｜六、论述题(20 分)

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00159｜南京工程学院｜2017｜structured_interview


### record_id

J29-00159

### question

用 2 分钟谈谈你的学习、工作、生活

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京工程学院

### school_normalized

南京工程学院

### province

江苏省

### year

2017

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第415行｜未标注题型｜原题号1

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00160｜南京工程学院｜2017｜structured_interview


### record_id

J29-00160

### question

你认为高校辅导员应该具备哪些素质，如果你任辅导员，说说自身不足

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京工程学院

### school_normalized

南京工程学院

### province

江苏省

### year

2017

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第415行｜未标注题型｜原题号2

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00161｜南京工程学院｜2017｜structured_interview


### record_id

J29-00161

### question

学校组织加强学风建设主题活动，如果你是系辅导员，你将如何指导学生有效开展活动。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京工程学院

### school_normalized

南京工程学院

### province

江苏省

### year

2017

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第415行｜未标注题型｜原题号3

### source_page

15

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00162｜江苏师范大学｜2016｜objective_question


### record_id

J29-00162

### question

作家萧伯纳说“人生有两大悲剧，一是没有得到你心爱的东西，另一是得到了你心爱的东西.”学者周国平说“人生有两大快乐，一是没有得到你心爱的东西，于是你可以去寻求和创造；另一是得到你心爱的东西，于是你可去品味和体验.”从哲学角度讲，两个观点存在差异的原因是( ) A.价值判断和价值选择具有社会历史性特征 B.人的认识结果是客观对主观的作用决定的 C.意识对于客观事物的反映是能动的反映 D.追求真理是一个永无止境的认识过程 (江苏省公务员2014)

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

reused_public_exam_question

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号1

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00163｜江苏师范大学｜2016｜objective_question


### record_id

J29-00163

### question

我国古代文人在诗词中常运用典故表达自己的思想感受，下列作品中没有使用典故的是： A.桃花潭水深千尺，不及汪伦送我情 B.蓬山此去无乡路，青鸟殷勤为探看 C.为报倾城随太守，亲射虎，看孙郎 D.东篱把酒黄昏后，有暗香盈袖 (江苏省公务员2014)

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

reused_public_exam_question

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号2

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00164｜江苏师范大学｜2016｜objective_question


### record_id

J29-00164

### question

下列法律谚语与其蕴含的法学理论对应正确的是( ) A.法无明文授权不得为：人的权利根源于法条 B.在法律面前人人平等：人的自由不能被剥夺 C.迟到的正义不是正义：效率是法的价值目标 D.民若不告则官必不究：诉权只能由个人行使 (江苏省公务员2014)

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

reused_public_exam_question

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号6

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00165｜江苏师范大学｜2016｜objective_question


### record_id

J29-00165

### question

下列关于国家主权及国防地理的表述，不正确的是( ) A.主权是联合国赋予国家的最基本的权利 B.一国的领海和领空都是其领土的组成部分 C.我国南海四大群岛是东沙、西沙、中沙和南沙群岛 D.我国与越南、缅甸、吉尔吉斯斯坦等十几个国家接壤 (江苏省公务员2016)

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

reused_public_exam_question

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号3

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00166｜江苏师范大学｜2016｜objective_question


### record_id

J29-00166

### question

下列历史人物与其著名言论对应错误的是( )(江苏省公务员2016) A.孟子——穷则独善其身，达则兼善天下 B.林则徐——苟利国家生死以，岂因祸福避趋之 C.梁启超——国家之主人为谁?即一国之民是也 D.曾国藩——天变不足畏，祖宗不足法，人言不足恤

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

reused_public_exam_question

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号6

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00167｜江苏师范大学｜2016｜objective_question


### record_id

J29-00167

### question

实际上雾霾形成的原因是多方面的，识别污染源是有效治理大气污染至关重要的环节。对京津冀区域而言，认清区域内污染源的共性及差别，有助于区域内地区 地对污染源进行综合治理。填入划横线部分最恰当的一项是( )(国家公务员2015) A.因地制宜 B.正本清源 C.齐心协力 D.有的放矢

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

reused_public_exam_question

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号9

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00168｜江苏师范大学｜2016｜objective_question


### record_id

J29-00168

### question

定义的使命是抽象、概括出某类事物的本质特征。当定义概括不了时，本应修正定义，而有人却常常“开除”那些概括不了的同类事物，以维护定义的纯洁性，这无疑是 .填入划横线部分最恰当的一项是( )(2014 北京公务员单选题) A.指鹿为马 B.削足适履 C.自欺欺人 D.掩耳盗铃

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

reused_public_exam_question

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号23

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00169｜江苏师范大学｜2016｜objective_question


### record_id

J29-00169

### question

下列关于人体血压的说法，正确的是 A.心室收缩时，动脉血压值称为收缩压，也称为低压 B.正常的血压是血液循环流动的前提，受到多种因素的影响 C.高血压对身体健康有重大危害，低血压不会影响身体健康 D.高血压病人应遵医嘱，服用降压药；血压正常后，应立刻停药

### material

(江苏省公务员2014)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第419行｜一、不定项选择题(10分)｜原题号25

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00170｜江苏师范大学｜2016｜short_answer


### record_id

J29-00170

### question

简述题(10分) 谈谈供给侧结构性改革的内涵。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第460行｜二、

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00171｜江苏师范大学｜2016｜essay_question


### record_id

J29-00171

### question

结合岗位的特点和要求，写一篇议论文《职业与事业》，至少1000字。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第463行｜四、作文题(60分)

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00172｜江苏师范大学｜2016｜activity_plan


### record_id

J29-00172

### question

1 习近平的三严三实中，“严以修身和谋事要实”，你认为作为辅导员怎么体现出这八个字? 2 七一就要来了，学校要策划一个迎七一活动，如果将策划活动任务交给你，你如何完成? 3 一位同学不爱学习，喜欢利用上课时间外出创业，近期这位学生外出创业赔了很多钱，父亲又查出了重病，作为辅导员，如何做?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

目标—对象—时间地点—流程—风险预案—评估

### school_original

江苏师范大学

### school_normalized

江苏师范大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

activity_plan

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第465行｜面试

### source_page

16

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00173｜淮北师范大学｜2017｜short_answer


### record_id

J29-00173

### question

党员要树立哪四个意识

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

淮北师范大学

### school_normalized

淮北师范大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第472行｜二、 简答题｜原题号1

### source_page

17

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00174｜淮北师范大学｜2017｜short_answer


### record_id

J29-00174

### question

辅导员职业能力九个方面

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

淮北师范大学

### school_normalized

淮北师范大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第472行｜二、 简答题｜原题号4

### source_page

17

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00175｜淮北师范大学｜2017｜case_analysis


### record_id

J29-00175

### question

学生家庭突发状况学习生活很糟，辅导员你该怎么办?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

淮北师范大学

### school_normalized

淮北师范大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第475行｜三、 案例题

### source_page

17

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00176｜淮北师范大学｜2017｜essay_question


### record_id

J29-00176

### question

结合习近平高校思想工作会议精神，谈辅导员如何做好思政工作

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

淮北师范大学

### school_normalized

淮北师范大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第476行｜四、 论述题

### source_page

17

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00177｜淮北师范大学｜2017｜blog_writing


### record_id

J29-00177

### question

关于新生适应问题写一篇博文。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

标题—立意—学生视角—案例/论据—行动倡议

### school_original

淮北师范大学

### school_normalized

淮北师范大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

blog_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第477行｜五、 写作

### source_page

17

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00178｜江苏第二师范学院｜2016｜fill_blank


### record_id

J29-00178

### question

江苏第二师范学院成立的时间是?前身是?校训精神?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第479行｜一、填空｜原题号1

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00179｜江苏第二师范学院｜2016｜fill_blank


### record_id

J29-00179

### question

马克思主义根本世界观和方法论

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第479行｜一、填空｜原题号5

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00180｜江苏第二师范学院｜2016｜short_answer


### record_id

J29-00180

### question

互联网+对辅导员工作的影响

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第484行｜三、简答｜原题号2

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00181｜江苏第二师范学院｜2016｜short_answer


### record_id

J29-00181

### question

作为新辅导员如何组建班委

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第484行｜三、简答｜原题号3

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00182｜江苏第二师范学院｜2016｜essay_question


### record_id

J29-00182

### question

你如何认识辅导员

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第487行｜四、论述(5题)｜原题号1

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00183｜江苏第二师范学院｜2016｜situational_simulation


### record_id

J29-00183

### question

李同学熬夜打游戏影响他人如何与之谈话

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

建立关系—倾听澄清—回应方案—边界与跟进

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

situational_simulation

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第487行｜四、论述(5题)｜原题号2

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00184｜江苏第二师范学院｜2016｜essay_question


### record_id

J29-00184

### question

新生入学不学习如何展开学业教育

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第487行｜四、论述(5题)｜原题号3

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00185｜江苏第二师范学院｜2016｜essay_question


### record_id

J29-00185

### question

徐玉玉事件，如何教育同学预防网络诈骗

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第487行｜四、论述(5题)｜原题号4

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00186｜江苏第二师范学院｜2016｜case_analysis


### record_id

J29-00186

### question

小李心情不好出去散散心关机失联了，你如何处理?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏第二师范学院

### school_normalized

江苏第二师范学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第487行｜四、论述(5题)｜原题号5

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00187｜苏州科技学院｜2015｜english_response


### record_id

J29-00187

### question

以“终身学习”为题，写一篇文章并翻译成英文。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—理由—例证—总结，注意英文表达

### school_original

江苏苏州科技学院

### school_normalized

苏州科技学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

english_response

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第496行｜写作

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00188｜苏州科技学院｜2015｜structured_interview


### record_id

J29-00188

### question

你做辅导员的优劣势

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

江苏苏州科技学院

### school_normalized

苏州科技学院

### province

江苏省

### year

2015

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第497行｜面试｜原题号1

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00189｜苏州科技学院｜2015｜case_analysis


### record_id

J29-00189

### question

一个贫困学生离奖学金的要求差一点点，辅导员破格为他申请了奖学金，你赞成吗?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏苏州科技学院

### school_normalized

苏州科技学院

### province

江苏省

### year

2015

### exam_stage

interview

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第497行｜面试｜原题号2

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00190｜苏州工业职业技术学院｜2015｜case_analysis


### record_id

J29-00190

### question

如何教育沉迷于网吧的学生?

### material

1h

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

苏州工业职业技术学院

### school_normalized

苏州工业职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第501行｜笔试 时间｜原题号1

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00191｜苏州工业职业技术学院｜2015｜exam_outline


### record_id

J29-00191

### question

考生考试舞弊如何处理?

### material

1h

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州工业职业技术学院

### school_normalized

苏州工业职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第501行｜笔试 时间｜原题号3

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00192｜苏州工业职业技术学院｜2015｜exam_outline


### record_id

J29-00192

### question

学生性格孤僻不合群怎么办?

### material

1h

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

苏州工业职业技术学院

### school_normalized

苏州工业职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第501行｜笔试 时间｜原题号4

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00193｜苏州工业职业技术学院｜2015｜case_analysis


### record_id

J29-00193

### question

案例题： 小A 身高 185，长相英俊，新生入学后军训时穿奇装异服，军训经常迟到。开学两周后，上课经常迟到，对任课老师不尊敬，上课用手提电脑或者戴耳机。在宿舍门口放一把湿拖把，让宿舍 同学进门时把鞋子擦干净再进门，其母亲每周来帮他洗衣服，而他在一旁若无其事抽烟。问：针对这一情况，如果是小 A 的辅导员将如何做？

### material

1h

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

苏州工业职业技术学院

### school_normalized

苏州工业职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第501行｜笔试 时间｜原题号5

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00194｜苏州工业职业技术学院｜2015｜structured_interview


### record_id

J29-00194

### question

如何看待辅导员职责

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

苏州工业职业技术学院

### school_normalized

苏州工业职业技术学院

### province

江苏省

### year

2015

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第509行｜面试(抽题)｜原题号1

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00195｜苏州工业职业技术学院｜2015｜structured_interview


### record_id

J29-00195

### question

大学生社会实践对学习社会主义核心价值观作用

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

苏州工业职业技术学院

### school_normalized

苏州工业职业技术学院

### province

江苏省

### year

2015

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第509行｜面试(抽题)｜原题号2

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00196｜苏州工业职业技术学院｜2015｜structured_interview


### record_id

J29-00196

### question

如何对待家庭离异的学生。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

苏州工业职业技术学院

### school_normalized

苏州工业职业技术学院

### province

江苏省

### year

2015

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第509行｜面试(抽题)｜原题号3

### source_page

18

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00197｜南京师范大学｜2015｜short_answer


### record_id

J29-00197

### question

大学生学业成绩的考核

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第515行｜二、简答｜原题号1

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00198｜南京师范大学｜2015｜short_answer


### record_id

J29-00198

### question

高校开展德育的途径

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第515行｜二、简答｜原题号2

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00199｜南京师范大学｜2015｜short_answer


### record_id

J29-00199

### question

简述高校辅导员的岗位职责

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第515行｜二、简答｜原题号3

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00200｜南京师范大学｜2015｜short_answer


### record_id

J29-00200

### question

简述高等教育的社会职能

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第515行｜二、简答｜原题号4

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00201｜南京师范大学｜2015｜short_answer


### record_id

J29-00201

### question

简述高等教育如何体现以人为本

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第515行｜二、简答｜原题号5

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00202｜南京师范大学｜2015｜official_writing


### record_id

J29-00202

### question

修改6 个公文的题目

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

文种判断—对象目的—格式—正文结构—落款

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

official_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第521行｜三、 公文题｜原题号1

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00203｜南京师范大学｜2015｜essay_question


### record_id

J29-00203

### question

高等教育大众化的利于弊

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第522行｜四、论述｜原题号1

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00204｜南京师范大学｜2015｜essay_question


### record_id

J29-00204

### question

信息技术对高等教育的影响

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第522行｜四、论述｜原题号2

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00205｜南京师范大学｜2015｜essay_question


### record_id

J29-00205

### question

目前大学生就业难的主要原因

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第522行｜四、论述｜原题号3

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00206｜南京师范大学｜2015｜essay_question


### record_id

J29-00206

### question

结合马哲原理谈谈“思政教育与社会实践结合”的必要性和重要性。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第522行｜四、论述｜原题号4

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00207｜南京师范大学｜2015｜material_analysis


### record_id

J29-00207

### question

高校辅导员岗位的特殊性

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第527行｜五、材料分析｜原题号1

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00208｜南京师范大学｜2015｜material_analysis


### record_id

J29-00208

### question

高校辅导员在高校教师和专业队伍中的合理定位

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

南京师范大学

### school_normalized

南京师范大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第527行｜五、材料分析｜原题号2

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00209｜南京财经大学红山学院｜2016｜fill_blank


### record_id

J29-00209

### question

国家中长期教育改革和发展规划纲要，第七部分高等教育，节选出来了，然后每一段的段首空着，让填空，一共五个空(10 分)

### material

申论(两道题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京财经大学红山学院

### school_normalized

南京财经大学红山学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第534行｜二、｜原题号1

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00210｜南京财经大学红山学院｜2016｜exam_outline


### record_id

J29-00210

### question

八百字以上的论文，如何提高学生创新能力

### material

申论(两道题)

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京财经大学红山学院

### school_normalized

南京财经大学红山学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第534行｜二、｜原题号2

### source_page

19

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00211｜南京财经大学｜2016｜exam_outline


### record_id

J29-00211

### question

名词解释：心境，激情，应激

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第538行｜笔试｜原题号1

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00212｜南京财经大学｜2016｜short_answer


### record_id

J29-00212

### question

简答题 (1)谈谈科学教育和人文教育的认识； (2)谈谈你对现代大学理念的理解； (3)谈谈通才教育和专才教育的理解；

### material



### sub_questions

(1)谈谈科学教育和人文教育的认识；；(2)谈谈你对现代大学理念的理解；；(3)谈谈通才教育和专才教育的理解；

### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第538行｜笔试｜原题号2

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00213｜南京财经大学｜2016｜material_analysis


### record_id

J29-00213

### question

材料题：心理健康问题方面

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第538行｜笔试｜原题号3

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00214｜南京财经大学｜2016｜structured_interview


### record_id

J29-00214

### question

在计算机室做心理测试题 第二阶段9：30：自我陈述； 题目抽签：

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号10

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00215｜南京财经大学｜2016｜structured_interview


### record_id

J29-00215

### question

你要去见一个重要的客人，却不小心溅了脏东西在衣服上，又没时间换了，怎么办?

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号1

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00216｜南京财经大学｜2016｜structured_interview


### record_id

J29-00216

### question

办公室门口你听到同事在向领导讲你工作上的失误，你会怎么办?

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号2

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00217｜南京财经大学｜2016｜structured_interview


### record_id

J29-00217

### question

如何开展第二课堂

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号3

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00218｜南京财经大学｜2016｜structured_interview


### record_id

J29-00218

### question

工作中做过的错事

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号4

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00219｜南京财经大学｜2016｜structured_interview


### record_id

J29-00219

### question

办公室接电话的礼节

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号5

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00220｜南京财经大学｜2016｜structured_interview


### record_id

J29-00220

### question

你认为辅导员有哪些职责?

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号7

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00221｜南京财经大学｜2016｜case_analysis


### record_id

J29-00221

### question

如果你班里有一名贫困生，父母外出打工，他最近沉迷网络，你作为他的政治辅导员你将怎么对他进行思想教育?

### material

第一阶段8: 30——9:

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

南京财经大学

### school_normalized

南京财经大学

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第545行｜面试｜原题号8

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00222｜南京铁道职业技术学院｜2017｜essay_question


### record_id

J29-00222

### question

中国要从中国制造到优质制造，发扬工匠精神，脚踏实地，为实现中华民族伟大复兴，围绕这个写一篇1000字左右的作文

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京铁道职业技术学院

### school_normalized

南京铁道职业技术学院

### province

江苏省

### year

2017

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第565行｜三、作文

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00223｜南京铁道职业技术学院｜2015｜short_answer


### record_id

J29-00223

### question

加强和改进大学生思想政治教育的指导思想，文件全称是什么

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京铁道职业技术学院

### school_normalized

南京铁道职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第572行｜三、简答｜原题号1

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00224｜南京铁道职业技术学院｜2015｜short_answer


### record_id

J29-00224

### question

党的四项基本原则

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京铁道职业技术学院

### school_normalized

南京铁道职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第572行｜三、简答｜原题号3

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00225｜南京铁道职业技术学院｜2015｜short_answer


### record_id

J29-00225

### question

高校教师师德禁行行为“红七条”

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京铁道职业技术学院

### school_normalized

南京铁道职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第572行｜三、简答｜原题号4

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00226｜南京铁道职业技术学院｜2015｜material_analysis


### record_id

J29-00226

### question

习大大马英九会面的意义结合材料进行论述。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

南京铁道职业技术学院

### school_normalized

南京铁道职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第577行｜四、论述｜原题号1

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00227｜南京铁道职业技术学院｜2015｜essay_question


### record_id

J29-00227

### question

辅导员队伍职业化的内容和重要性，你怎么看待辅导员职业?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

南京铁道职业技术学院

### school_normalized

南京铁道职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

essay_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第577行｜四、论述｜原题号2

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00228｜南京铁道职业技术学院｜2015｜blog_writing


### record_id

J29-00228

### question

面对学生就业难，难就业，作为辅导员你认为怎么做? 不少 400 字，文体不限。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

标题—立意—学生视角—案例/论据—行动倡议

### school_original

南京铁道职业技术学院

### school_normalized

南京铁道职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

blog_writing

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第580行｜五、博文写作

### source_page

20

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00229｜徐州工程学院｜2016｜exam_outline


### record_id

J29-00229

### question

从自身专业性格能力等方面谈谈和所报岗位的关系

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

徐州工程学院

### school_normalized

徐州工程学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第589行｜未标注题型｜原题号1

### source_page

21

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00230｜徐州工程学院｜2016｜exam_outline


### record_id

J29-00230

### question

小王去工作单位一开始大家对他很热情，一段时间后冷淡了，为什么怎么办

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

徐州工程学院

### school_normalized

徐州工程学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第589行｜未标注题型｜原题号2

### source_page

21

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00231｜徐州工程学院｜2016｜exam_outline


### record_id

J29-00231

### question

你认为你个人发展和徐州工程学院有什么关系?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

徐州工程学院

### school_normalized

徐州工程学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第589行｜未标注题型｜原题号3

### source_page

21

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00232｜东南大学｜2016｜exam_outline


### record_id

J29-00232

### question

辅导员的定义和个人竞争优势

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

东南大学

### school_normalized

东南大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第596行｜未标注题型｜原题号1

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00233｜东南大学｜2016｜case_analysis


### record_id

J29-00233

### question

案例分析(我分析的是校园学院篮球赛斗殴事件)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

东南大学

### school_normalized

东南大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第596行｜未标注题型｜原题号2

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00234｜东南大学｜2016｜short_answer


### record_id

J29-00234

### question

问答环节(原则上问一个问题，但是我被问了不少于5 个，结合简历问)

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

东南大学

### school_normalized

东南大学

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第596行｜未标注题型｜原题号3

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00235｜盐城工学院｜2016｜fill_blank


### record_id

J29-00235

### question

抗争胜利70 周年纪念日；屠呦呦青蒿素；巴黎气候签订了什么，对什么问题达成共识新民主革命的三大法宝；中国梦内涵

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

fill_blank

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第600行｜一、填空题

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00236｜盐城工学院｜2016｜exam_outline


### record_id

J29-00236

### question

四个全面的相互关系

### material

分析题

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第603行｜三、｜原题号1

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00237｜盐城工学院｜2016｜exam_outline


### record_id

J29-00237

### question

全面深化改革中的经济体制改革

### material

分析题

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第603行｜三、｜原题号2

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00238｜盐城工学院｜2016｜exam_outline


### record_id

J29-00238

### question

社会主义的本质是以人为本

### material

分析题

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

exam_outline

### authenticity

exam_outline

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第603行｜三、｜原题号3

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00239｜盐城工学院｜2016｜short_answer


### record_id

J29-00239

### question

你如何看待辅导员这个职业

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第606行｜四、 简答题｜原题号1

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00240｜盐城工学院｜2016｜short_answer


### record_id

J29-00240

### question

思政教育的基本原则

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第606行｜四、 简答题｜原题号2

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00241｜盐城工学院｜2016｜case_analysis


### record_id

J29-00241

### question

学生创业想退学怎么办

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第607行｜五、案例分析｜原题号1

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00242｜盐城工学院｜2016｜case_analysis


### record_id

J29-00242

### question

学生干部没有拿到奖学金，想考研，想要辞职，怎么办?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第607行｜五、案例分析｜原题号2

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00243｜盐城工学院｜2016｜theme_class_meeting


### record_id

J29-00243

### question

如果给一年级新生开班会，你怎么开?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

目标—对象—流程—互动—评估

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

written

### question_type

theme_class_meeting

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第607行｜五、案例分析｜原题号3

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00244｜盐城工学院｜2016｜speech


### record_id

J29-00244

### question

结合学校的实际，你如何履行辅导员的职责面试：时长10 分钟共计两题 第一题：围绕“我”、“辅导员”做一个演讲； 第二题：两个学生谈恋爱，女生后来不同意，男生一直纠缠威胁，对女生造成了心理阴影，学习成绩下降，想要退学，作为辅导员你怎么做?

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

主题—对象—情感—事例—号召

### school_original

江苏盐城工学院

### school_normalized

盐城工学院

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

speech

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第611行｜六、 论述题

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00245｜徐州幼儿师范高等专科学校｜2016｜structured_interview


### record_id

J29-00245

### question

学生追求女生采取极端手段，疯狂发短信、人前表白、对女生已经造成影响。辅导员怎么处理?5分钟

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

表态—分析—行动—岗位匹配—升华

### school_original

徐州幼儿师范高等学校

### school_normalized

徐州幼儿师范高等专科学校

### province

江苏省

### year

2016

### exam_stage

interview

### question_type

structured_interview

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第623行｜一、

### source_page

22

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00246｜无锡工艺职业技术学院｜2015｜material_analysis


### record_id

J29-00246

### question

用管理学和教育学的知识写一段评价，材料内容是班主任对学生的评语，大概是负面写的比较多，一个学生写的比较好。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

无锡工艺职业技术学院

### school_normalized

无锡工艺职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第631行｜写作方面两道材料题，｜原题号1

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00247｜无锡工艺职业技术学院｜2015｜material_analysis


### record_id

J29-00247

### question

关于硕士研究生就业难，写作字数不少于 1500 字。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

无锡工艺职业技术学院

### school_normalized

无锡工艺职业技术学院

### province

江苏省

### year

2015

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第631行｜写作方面两道材料题，｜原题号2

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00248｜扬州大学｜2015｜short_answer


### record_id

J29-00248

### question

《大学章程》编著的意义

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第636行｜一、简答｜原题号3

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00249｜扬州大学｜2015｜short_answer


### record_id

J29-00249

### question

辅导员的工作要求，

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第636行｜一、简答｜原题号4

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00250｜扬州大学｜2015｜case_analysis


### record_id

J29-00250

### question

怎么对醉酒进医院和早恋的学生进行教育沟通。

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

定性—原因—措施—跟进

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2015

### exam_stage

written

### question_type

case_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第639行｜二、 材料题

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；原文未给出完整标准答案。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00251｜扬州大学｜2017｜objective_question


### record_id

J29-00251

### question

供给侧结构性改革

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号1

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00252｜扬州大学｜2017｜objective_question


### record_id

J29-00252

### question

各级领导机关和领导干部

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号3

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00253｜扬州大学｜2017｜objective_question


### record_id

J29-00253

### question

坚定中国特色社会主义道路自信、理论自信、制度自信。

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号4

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00254｜扬州大学｜2017｜objective_question


### record_id

J29-00254

### question

必须把坚定理想信念作为开展党内政治生活的首要任务

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号5

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00255｜扬州大学｜2017｜objective_question


### record_id

J29-00255

### question

学党章党规、学系列讲话，做合格党员

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号6

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00256｜扬州大学｜2017｜objective_question


### record_id

J29-00256

### question

十三五，以提高发展质量和效益为中心推进经济、政治、文化、社会、生态文明建设

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号7

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00257｜扬州大学｜2017｜objective_question


### record_id

J29-00257

### question

不断提高党的创造力、凝聚力、战斗力，建设学习型、服务型、创新型的马克思主义执政，整体推进党的思想、组织、作风、反腐倡廉、制度建设，全面提高党的建设科学化水平。

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号8

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00258｜扬州大学｜2017｜objective_question


### record_id

J29-00258

### question

中国共产党党员必须全心全意为人民服务

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号9

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00259｜扬州大学｜2017｜objective_question


### record_id

J29-00259

### question

教师法，本法适用于在各级各类学校和其他教育机构中专门从事教育教学工作的教师

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号10

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00260｜扬州大学｜2017｜objective_question


### record_id

J29-00260

### question

思政会议：必须围绕学生、关照学生、服务学生，不断提高学生思想水平、政治觉悟、道德品质、文化素养，让学生成为德才兼备、全面发展的人才。

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号11

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00261｜扬州大学｜2017｜objective_question


### record_id

J29-00261

### question

中国共产党第十八次全国代表大会对我国经济建设、政治建设、文化建设、社会建设和生态文明建设，“五位一体”的中国特色社会主义建设进行了部署。

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号12

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00262｜扬州大学｜2017｜objective_question


### record_id

J29-00262

### question

建设生态文明，是关系人民福祉、关乎民族未来的长远

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号13

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00263｜扬州大学｜2017｜objective_question


### record_id

J29-00263

### question

自由、平等、公正、法治(是社会层面的价值取向)

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号14

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00264｜扬州大学｜2017｜objective_question


### record_id

J29-00264

### question

一般来说，高等教育毛入学率在 15%以下时属于精英教育阶段，15%—50%为高等教育大众化阶段，50%以上为高等教育普及化阶段

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号15

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00265｜扬州大学｜2017｜objective_question


### record_id

J29-00265

### question

扬州淮扬文化，徐州楚汉文化，苏锡常吴文化

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号16

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00266｜扬州大学｜2017｜objective_question


### record_id

J29-00266

### question

党的思想路线是一切从实际出发，理论联系实际，实事求是，在实践中检验真理和发展真理。”

### material

(涉及的范围比较广，涉及十三五规划、十八届六中全会、两学一做、党章党规、全国思政会议、教师相关、心理学相关的、社会主义核心价值观等等) 涉及的选择题填空的考点回忆如下：

### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

objective_question

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第641行｜一、选择题(1分*60)｜原题号17

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00267｜扬州大学｜2017｜short_answer


### record_id

J29-00267

### question

立德树人的目标和意义

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第659行｜二、简答题(10分*2)｜原题号1

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00268｜扬州大学｜2017｜short_answer


### record_id

J29-00268

### question

双一流建设总体目标

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

观点—依据—做法—总结

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

short_answer

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第659行｜二、简答题(10分*2)｜原题号2

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

true

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00269｜扬州大学｜2017｜material_analysis


### record_id

J29-00269

### question

依法治校的意义和如何尊重和保护学生权利

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第661行｜三、材料题(15分*2)｜原题号1

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理

## J29-00270｜扬州大学｜2017｜material_analysis


### record_id

J29-00270

### question

根据材料写出关于学风建设的问题，原因以及解决措施

### material



### sub_questions



### answer

原资料未提供可核验标准答案

### answer_framework

材料概括—问题—原因—措施—启示

### school_original

扬州大学

### school_normalized

扬州大学

### province

江苏省

### year

2017

### exam_stage

written

### question_type

material_analysis

### authenticity

recalled_real_exam

### source_file

3-02【江苏省】29校真题.docx

### source_section

学校正文第661行｜三、材料题(15分*2)｜原题号2

### source_page

23

### source_status

valid_extractable_source

### content_type

recalled_exam_collection

### temporal_status

historical_exam

### needs_current_answer_verification

false

### notes

来源为考生回忆汇总，不是官方原卷；题干、答案和年份可能存在记忆偏差或版本差异。

### duplicate_relationship

未发现规范化精确重复；真实性和时效性按字段处理
