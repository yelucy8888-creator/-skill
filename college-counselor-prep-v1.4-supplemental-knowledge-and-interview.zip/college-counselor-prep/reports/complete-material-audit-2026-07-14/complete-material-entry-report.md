# 完整资料条目报告

- 审计时间：`2026-07-14T13:54:51`
- 当前 Skill 版本：`v1.4.0-supplemental-knowledge-and-interview`（从 `version.md` 实读）
- 审计范围：当前 Skill 根目录、题库/知识库/模板/评分/流程/索引、项目来源登记层、桌面第3章目录、交付 ZIP。
- 操作边界：本次只盘点、统计、核对和报告；仅修复已确认的旧索引路径，不修改题目正文或重新导入资料。
- 最终结论：**PASS_WITH_WARNINGS**

## 1. 结论摘要

当前 Skill 包含 `103` 个文件；结构化记录共 `13423` 条，其中题目 `11476` 条、知识记录 `1947` 条。来源盘点按登记层分别统计，避免把桌面原始文件、raw-materials 归档副本、converted-text 中间产物和 Skill 输出重复冒充为独立内容来源。

桌面第3章目录扫描到 `336` 个物理文件；当前 v1.4 来源映射登记 `57` 条；项目 manifest 登记 `81` 条；Skill 内没有 PDF/DOC/DOCX 原始文件。

## 2. 来源与处理状态

来源状态计数（按审计登记条目层，不将不同层相加为唯一来源数）：

- `content_already_covered`：5
- `excluded_by_user`：1
- `manual_review_required`：148
- `processed`：25
- `source_evidence_only`：327

来源登记层计数：

- `converted-text`：3
- `desktop_source`：336
- `mapping_reference`：1
- `raw-materials`：85
- `registered_manifest_reference`：81

关键来源状态核对：

- `3-02【江苏省】29校真题.docx`：`source_status=valid_extractable_source`，`content_type=recalled_exam_collection`，`province=江苏省`，`temporal_status=historical_exam`，已导入结构化题库。
- `3.2 【江苏省】29校真题-2f83d1e0a315.docx.qkdownloading`：`source_status=excluded_by_user`，`exclude_reason=incomplete_download_file`；与完整 DOCX 分开登记。
- `溪溪状元笔记`完整版：图像型来源保留人工复核状态；可提取分卷作为文字主来源。
- `溪溪通关密卷2025.docx`：登记为已有 v1.3 内容覆盖，不重复导入。

## 3. 结构化条目统计

- 题目记录：`11476`
- 知识记录：`1947`
- 结构化记录总数：`13423`
- 默认 usable 题库：`10681`
- v1.4 培训题：`525`（笔试364、面试161）
- 江苏29校新增记录：`270`（具体题目 `216`，题型概述 `54`）
- v1.4 SUP 补充知识记录：`1947`；另有 legacy policy/current-affairs reference cards 单独统计在 CSV 中。

题型、真实性、考试阶段和时效性分布见 `record-type-distribution.csv`、`temporal-status-summary.csv`。旧 usable 题库未全部使用 v1.4 统一字段，因此报告将“明确字段统计”和“未显式标注”分开，不把推断标签当作来源事实。

## 4. 江苏省29校真题核对

- 识别出有结构化记录的规范化学校：`29` 所；学校/年份明细见 `school-year-record-breakdown.csv`。
- 记录涉及年份：`2015、2015上半年、2015下半年、2016、2017、2018、2019`。原来源覆盖范围按 v1.4 记录为 `2015–2019`。
- 新增最终记录：`270`；具体题目 `216`；考试题型概述 `54`。
- 笔试记录：`213`；面试记录：`57`。
- authenticity：`recalled_real_exam=209`，`exam_outline=54`，`reused_public_exam_question=7`，`reference_material=0`，`unknown_authenticity=0`。
- 与现有题库精确重复：`2`；源文件内部精确重复：`1`；近似重复提示：`0`。
- 因内容不足未生成独立题目记录：v1.4 记录统计为 `79` 个原始片段；候选流另有 `53` 条解析后未达到独立记录阈值的残余候选，二者统计口径不同。

候选流核算：`326 = 216 + 54 + 2 + 1 + 53`，其中 `216` 为具体题目、`54` 为题型概述、`2` 为现有精确重复、`1` 为内部精确重复、`53` 为不足以形成独立记录的候选残余；差额为 `0`。详见 `candidate-flow-audit.csv`。

## 5. 时间有效性、真实性和使用边界

江苏29校资料统一标记为 `historical_exam`，适合研究历史命题规律、题型和高频主题；涉及现行政策、法规、处分制度、辅导员职责、学校校情或时政数字时，答题必须增加现行官方文件复核，不得直接把旧题答案当作当前事实。五类真实性标签按原文证据区分，未把参考材料或题型概述包装成完整真题。

## 6. 去重、索引和完整性审计

- 结构化记录 ID 重复：`0` 个重复 ID。
- 索引绝对路径在修复后仍无效：`0`；无效相对路径：`0`。
- 允许的索引修复：未发现需要执行的修复。
- 未在导航/索引文本中逐文件出现的 Markdown 候选：`16`；这属于可发现性警告，不等于内容缺失。
- 临时文件：`0`；空文件：`0`；UTF-8 解析错误：`0`。
- 交付 ZIP：`103` 个条目，压缩包校验：`pass`，禁止原始文档条目：`0`。

## 7. 交付物

本目录文件：

- `complete-source-inventory.csv`
- `complete-record-statistics.csv`
- `source-to-output-mapping.csv`
- `record-type-distribution.csv`
- `school-year-record-breakdown.csv`
- `candidate-flow-audit.csv`
- `unresolved-materials.csv`
- `temporal-status-summary.csv`
- `duplicate-summary.csv`
- `package-integrity-report.md`

交付 ZIP：`C:\Users\Administrator\Documents\New project\college-counselor-skill-project\delivery\college-counselor-prep-v1.4-supplemental-knowledge-and-interview.zip`；大小 `4118369` bytes；SHA-256 `f4620ca60005151b4de3287e057e2f55c730c1dd20c59ff311feeca987494456`。

## 8. 审计警告

- 16 structured/template Markdown files are not individually mentioned in navigation/index text
- 83 unresolved/evidence-only material entries remain documented
- 148 source-layer entries require manual review or are outside the current v1.4 mapping

## 附：未纳入结构化总数的既有参考章节

- legacy policy/current-affairs reference sections：`14`；这些是既有参考文档的二级章节，不是 v1.4 SUP 记录，因此不计入 `13423` 条结构化记录。

## 索引修复审计轨迹

- 已确认并修复旧的 `processed/question-bank/final-usable-question-bank/usable-question-bank` 绝对路径前缀，改为当前 Skill 内的 `question-bank/usable` 相对路径；复核结果为无效绝对/相对索引路径均为 `0`。本次未修改题目内容。
