# Package integrity report

- Audit timestamp: `2026-07-14T13:54:51`
- Skill version: `v1.4.0-supplemental-knowledge-and-interview`
- Current Skill files: `103`
- File extensions: `{'.csv': 13, '.md': 90}`
- UTF-8 parse errors: `0`
- Empty files: `0`
- Temporary files in Skill: `0`
- Markdown files over 1 MiB: `5`
- Index invalid absolute paths after repair: `0`
- Index invalid relative paths: `0`
- Orphan Markdown candidates: `16`
- Delivery ZIP: `C:\Users\Administrator\Documents\New project\college-counselor-skill-project\delivery\college-counselor-prep-v1.4-supplemental-knowledge-and-interview.zip`
- Delivery ZIP size: `4118369 bytes`
- Delivery ZIP SHA-256: `f4620ca60005151b4de3287e057e2f55c730c1dd20c59ff311feeca987494456`
- ZIP entries: `103`
- ZIP test: `pass`
- Forbidden source entries in ZIP: `0`
- Conclusion: **PASS_WITH_WARNINGS**

## Warnings

- 16 structured/template Markdown files are not individually mentioned in navigation/index text
- 83 unresolved/evidence-only material entries remain documented
- 148 source-layer entries require manual review or are outside the current v1.4 mapping

## Large Markdown files

- `skill/college-counselor-prep/question-bank/indexes/excluded-question-report.md`: 4762393 bytes
- `skill/college-counselor-prep/question-bank/indexes/usable-question-index.md`: 2134328 bytes
- `skill/college-counselor-prep/question-bank/usable/current-affairs/current-affairs-usable.md`: 7786853 bytes
- `skill/college-counselor-prep/question-bank/usable/mixed/mixed-usable.md`: 3678443 bytes
- `skill/college-counselor-prep/question-bank/usable/subjective/short-answer-usable.md`: 1117495 bytes

## Permitted index repair audit trail

- The old absolute `processed/question-bank/final-usable-question-bank/usable-question-bank` prefix was identified as an invalid packaged-Skill index target and replaced with the relative `question-bank/usable` prefix. The current scan confirms zero invalid index paths. No question content was changed.
