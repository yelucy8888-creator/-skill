# v1.4 明确排除文件

|文件|状态|原因|
|---|---|---|
|`3.2 【江苏省】29校真题-2f83d1e0a315.docx.qkdownloading`|`excluded_by_user`|未完成下载；用户明确放弃；不 OCR、不修复、不进入 review_pending|
|`溪溪状元笔记2025.docx`|`image_only_probe`|完整版正文 XML 无可提取段落；仅作来源登记，不虚构文字|
|`1-07【思政理论】马原+毛概+中特.docx`|`image_only_probe`|正文 XML 无可提取段落；不虚构文本|

## 不属于排除项的完整来源

`3-02【江苏省】29校真题.docx` 是新提供的、可正常读取的完整 DOCX，已作为 `valid_extractable_source` 导入；它与上面的 `.qkdownloading` 临时文件是两个不同来源，不能混淆。

