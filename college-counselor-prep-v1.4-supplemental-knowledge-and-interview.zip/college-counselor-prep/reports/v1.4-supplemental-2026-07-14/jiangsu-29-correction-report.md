# v1.4 江苏省 29 校完整 DOCX 修正导入报告

- 完整来源文件：`3-02【江苏省】29校真题.docx`
- 完整来源 SHA-256：`c77c5fb7240e6fb46402991518b31b6db31d666a1b364ae614f556be070e488c`
- 完整 DOCX：55491 bytes；清洗后可提取段落 663 个
- 原 `.qkdownloading` 临时文件：`3.2 【江苏省】29校真题-2f83d1e0a315.docx.qkdownloading`，仍为 `excluded_by_user`，原因 `incomplete_download_file`。
- 识别学校：目录 29 所；结构化记录涉及规范化学校 29 所。
- 考试年份范围：2015—2019；原文另含 2014—2016 公务员公开题复用标注。
- 候选记录：326；去重后新增记录：270。
- 新增完整题目：216；新增考试题型概述：54。
- 新增笔试记录：213；新增面试记录：57。
- authenticity：recalled_real_exam=209；exam_outline=54；reused_public_exam_question=7；reference_material=0；unknown_authenticity=0。
- 与现有题库精确重复：2；文件内部精确重复：1；近似重复提示：0。
- 因内容不完整而未生成具体题目记录的片段：79。
- 最终 Skill 题目记录数：11476；含知识记录的结构化总记录数：13423。

## 真实性和时效边界

- 有明确学校、年份和具体题干的记录标记为 `recalled_real_exam`，并保留“考生回忆汇总、非官方原卷”提示。
- 只有题型、分值、考试范围或明确缺题的记录标记为 `exam_outline`。
- 明确标注国家公务员、江苏公务员、北京公务员或国考/行测原题复用的记录标记为 `reused_public_exam_question`。
- 参考材料不转化为完整真题；无法判断真实性的记录标记为 `unknown_authenticity`。
- 全部记录标记为 `historical_exam`；涉及现行政策、法规、职责、处分、学生管理、校情或政策数字的记录另标记 `needs_current_answer_verification=true`。

## 统计文件

- `final-record-counts.csv`：最终统计口径。
- `jiangsu-school-year-breakdown.csv`：学校、原文名称、年份和记录数。
- 结构化题库：`question-bank/recalled_exam_bank/jiangsu-29-schools-2015-2019.md`。
