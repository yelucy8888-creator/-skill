# Version

- 版本号：v1.4.0-supplemental-knowledge-and-interview
- 版本名称：高校辅导员备考 Skill 补充知识与面试训练版
- 生成日期：2026-07-14
- 主要功能：政策解释、笔试训练、案例分析、结构化面试、公文写作、时政复习、答案批改、错题复盘、补充知识卡和面试专项训练
- 默认可用题库：`question-bank/usable/`，10681 道
- v1.4 新增训练题：525 道（笔试 364 道，面试 161 道）
- v1.4 新增结构化知识记录：1947 条
- v1.4 扫描文件：336 个；主处理 DOCX：25 个（含新增江苏 29 校完整 DOCX）
- v1.4 去重审计：精确重复/已有记录 186 条；近似重复 8 条
- 不包含：raw-materials、converted-text、full-extraction、原始 PDF/DOCX 和旧分层工程目录
- 已知限制：基础题库中部分题目需要人工核对；新增培训题、法规与政策整理需回到现行官方文件复核；图像型资料未 OCR；时政题有时效性风险

## v1.4 变更摘要

- 纳入溪溪状元笔记 2025 的两个可提取分卷，并按政策理论、学生工作、辅导员角色、案例分析、面试表达、写作材料等主题拆分。
- 纳入 1-01 至 1-04、1-06 至 1-13（按任务范围跳过 1-05）以及 5-0 至 5-10 的结构化知识和训练记录。
- 将范例、模板、培训题、真题回忆与官方依据分层；不把培训材料标记为 `verified_real_exam`。
- 将同名 PDF 设为来源/版面证据，将哈希后缀副本设为精确文件重复，将 `3.2 【江苏省】29校真题-2f83d1e0a315.docx.qkdownloading` 标记为 `excluded_by_user`。
- 修正江苏 29 校来源：`3-02【江苏省】29校真题.docx` 设为 `valid_extractable_source`，新增 270 条去重后记录；旧 `.qkdownloading` 仍以 `incomplete_download_file` 排除。
- 江苏回忆题按学校、年份、笔试/面试和题型拆分，并区分 `recalled_real_exam`、`exam_outline`、`reused_public_exam_question`、`reference_material`、`unknown_authenticity`。
- 历史政治理论、旧政策、旧年度预测和两会/7.1/二十大相关旧资料统一保留时效性提示，不默认当作当前时政。

## 审计报告

- `reports/v1.4-supplemental-2026-07-14/supplemental-ingestion-report.md`
- `reports/v1.4-supplemental-2026-07-14/source-mapping-supplement.csv`
- `reports/v1.4-supplemental-2026-07-14/duplicate-audit-supplement.md`
- `reports/v1.4-supplemental-2026-07-14/temporal-validity-audit.md`
- `reports/v1.4-supplemental-2026-07-14/excluded-files.md`
- `reports/v1.4-supplemental-2026-07-14/jiangsu-29-correction-report.md`
- `reports/v1.4-supplemental-2026-07-14/final-record-counts.csv`
- `reports/v1.4-supplemental-2026-07-14/unresolved-sources-final.md`
