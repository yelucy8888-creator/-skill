# Package File List

## 根目录文件
- `SKILL.md`
- `README.md`
- `quick-start.md`
- `source-disclaimer.md`
- `version.md`
- `delivery-checklist.md`

## references
- `references/counselor-core-policy-cards.md`
- `references/current-affairs-2025-2026.md`
- `references/source-reliability-report.md`

## question-bank
- `question-bank/indexes/duplicate-resolution-report.md`
- `question-bank/indexes/excluded-question-report.md`
- `question-bank/indexes/final-phase6-readiness-report.md`
- `question-bank/indexes/usable-question-index.md`
- `question-bank/indexes/usable-question-quality-report.md`
- `question-bank/question-bank-risk-note.md`
- `question-bank/question-bank-usage-guide.md`
- `question-bank/usable/case-analysis/case-analysis-usable.md`
- `question-bank/usable/current-affairs/current-affairs-usable.md`
- `question-bank/usable/mixed/mixed-usable.md`
- `question-bank/usable/objective/choice-usable.md`
- `question-bank/usable/objective/fill-blank-usable.md`
- `question-bank/usable/objective/judgment-usable.md`
- `question-bank/usable/public-writing/public-writing-usable.md`
- `question-bank/usable/structured-interview/structured-interview-usable.md`
- `question-bank/usable/subjective/essay-usable.md`
- `question-bank/usable/subjective/short-answer-usable.md`

## templates
- `templates/case-analysis-template.md`
- `templates/current-affairs-answer-template.md`
- `templates/essay-answer-template.md`
- `templates/interview-expression-bank.md`
- `templates/public-writing-template-draft.md`
- `templates/public-writing-template.md`
- `templates/short-answer-template.md`
- `templates/structured-interview-template.md`

## rubrics
- `rubrics/answer-grading-rules.md`
- `rubrics/case-analysis-rubric.md`
- `rubrics/current-affairs-rubric.md`
- `rubrics/structured-interview-rubric.md`
- `rubrics/written-exam-rubric.md`

## workflows
- `workflows/case-analysis-training-workflow.md`
- `workflows/daily-training-workflow.md`
- `workflows/final-sprint-workflow.md`
- `workflows/mock-interview-workflow.md`
- `workflows/weekly-review-workflow.md`
- `workflows/wrong-question-review-workflow.md`

## reports
- `reports/excluded-files-report.md`
- `reports/included-files-report.md`
- `reports/known-limitations.md`
- `reports/phase6-build-report.md`
- `reports/stage7-docs-check.md`
- `reports/stage7-exclusion-check.md`
- `reports/stage7-final-test-report.md`
- `reports/stage7-question-bank-check.md`
- `reports/stage7-risk-consistency-check.md`
- `reports/stage7-sample-task-test.md`
- `reports/stage7-skill-md-check.md`
- `reports/stage7-structure-check.md`
- `reports/stage7-templates-rubrics-workflows-check.md`
